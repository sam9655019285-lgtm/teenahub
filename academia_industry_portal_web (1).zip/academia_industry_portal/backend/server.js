/*
 * server.js — Phase 13 backend entry point.
 *
 * Zero external dependencies on purpose (Node's built-in `http` only)
 * so `npm install` has nothing that can fail or go stale, and the
 * whole backend is easy to read end-to-end for a college project. See
 * README.md "Phase 13" for setup and how this talks to
 * js/api/apiClient.js.
 */

const http = require("http");
const { URL } = require("url");

const { loadEnv } = require("./utils/env");
loadEnv();

const logger = require("./utils/logger");
const { createRouter } = require("./utils/router");
const jobsRoute = require("./routes/jobs");
const industryDataRoute = require("./routes/industryData");
const skillsRoute = require("./routes/skills");

const PORT = process.env.PORT || 3000;
// ---- CORS: any localhost/127.0.0.1 origin is allowed in development
// (this is a local dev API with no secrets reachable from the
// frontend anyway — see backend/README notes). Set CORS_ORIGIN to a
// comma-separated list to lock this down for a real deployment.
const configuredOrigins = (process.env.CORS_ORIGIN || "")
  .split(",").map((o) => o.trim()).filter(Boolean);

function isAllowedOrigin(origin) {
  if (!origin) return true; // non-browser tools (curl, etc.)
  if (configuredOrigins.includes(origin)) return true;
  if ((process.env.NODE_ENV || "development") !== "production") {
    try {
      const { hostname } = new URL(origin);
      if (hostname === "localhost" || hostname === "127.0.0.1") return true;
    } catch { /* fall through to deny */ }
  }
  return false;
}

const router = createRouter();
router.get("/", (req, res, ctx) => ctx.sendJson(200, {
  name: "Academia-Industry Portal API", status: "running",
  demoMode: String(process.env.DEMO_MODE || "true") === "true",
}));
router.get("/api/jobs", jobsRoute.getJobs);
router.get("/api/industry/trends", industryDataRoute.getTrends);
router.get("/api/industry/status", industryDataRoute.getStatus);
router.get("/api/skills/demand", skillsRoute.getDemand);
router.get("/api/skills/aliases", skillsRoute.getAliases);

const server = http.createServer(async (req, res) => {
  const origin = req.headers.origin;
  if (isAllowedOrigin(origin)) {
    res.setHeader("Access-Control-Allow-Origin", origin || "*");
    res.setHeader("Access-Control-Allow-Methods", "GET,POST,OPTIONS");
    res.setHeader("Access-Control-Allow-Headers", "Content-Type");
  } else {
    logger.warn(`Blocked CORS request from origin: ${origin}`);
  }
  if (req.method === "OPTIONS") { res.writeHead(204); res.end(); return; }

  const url = new URL(req.url, `http://${req.headers.host}`);
  const query = Object.fromEntries(url.searchParams.entries());

  const ctx = {
    query,
    logger,
    sendJson(status, body) {
      res.writeHead(status, { "Content-Type": "application/json" });
      res.end(JSON.stringify(body));
    },
  };

  logger.debug(`${req.method} ${url.pathname}`);
  const match = router.match(req.method, url.pathname);
  if (!match) { ctx.sendJson(404, { error: "Not found" }); return; }

  try {
    await match.handler(req, res, ctx);
  } catch (err) {
    logger.error("Unhandled error:", err.message);
    const isProd = (process.env.NODE_ENV || "development") === "production";
    ctx.sendJson(500, { error: "Internal server error", detail: isProd ? undefined : err.message });
  }
});

server.listen(PORT, () => {
  logger.info(`Academia-Industry Portal API listening on http://localhost:${PORT}`);
  logger.info(`Demo mode: ${String(process.env.DEMO_MODE || "true") === "true" ? "ON (mock data)" : "OFF (live providers)"}`);
  logger.info(`Allowed CORS origins: any localhost/127.0.0.1 origin (dev)${configuredOrigins.length ? `, plus: ${configuredOrigins.join(", ")}` : ""}`);
});

module.exports = server;
