# Academia–Industry Skill Bridge & Collaboration Portal — Web Edition

A browser-based rewrite of the original Python + Streamlit prototype. This
version is **pure HTML5 + CSS3 + vanilla JavaScript (ES6+)** — no Streamlit,
no Python, no build step, no backend, and no external frameworks (no React,
Vue, Angular, Node backend, etc.). It runs as an ordinary static website.

## How to run

Open `index.html` through a local static server (not `file://`, because the
Web Crypto API used for password hashing requires a secure context):

- **VS Code:** install the "Live Server" extension → right-click
  `index.html` → "Open with Live Server".
- **Any other static server**, e.g. from this folder:
  ```
  python3 -m http.server 8000
  ```
  then visit `http://localhost:8000/`.

`index.html` redirects to `login.html` (or straight to your dashboard if
you're already logged in this browser).

## Demo accounts

Seeded automatically on first run from the original `data/users.json`
(same accounts, same password hashes):

| Role | Email | Password |
|---|---|---|
| Student | student@demo.com | student123 |
| Industry | industry@demo.com | industry123 |
| Academician | academician@demo.com | academician123 |
| Institution | institution@demo.com | institution123 |

You can also register a brand-new account from `register.html` for any role.

## Folder structure

```
academia_industry_portal/
├── index.html            entry point — redirects to login or dashboard
├── login.html             Phase 11 login
├── register.html          Phase 11 registration
├── student.html            Student dashboard shell (Phases 1–7)
├── industry.html           Industry dashboard shell (Phase 8)
├── academician.html        Academician dashboard shell (Phase 9–10)
├── institution.html        Institution dashboard shell (Phase 9–10)
├── css/style.css           one shared, responsive stylesheet
└── js/
    ├── data.js              all sample/reference data (was data/*.py)
    ├── storage.js            localStorage wrapper — replaces st.session_state
    ├── auth.js                Phase 11 auth (SHA-256 via Web Crypto API)
    ├── ui.js                  reusable render helpers (cards, badges, toasts…)
    ├── navigation.js           sidebar + tabs shell
    ├── engine.js               Phase 3/4/7 scoring engines (pure functions)
    ├── analytics-engine.js     Phase 8 candidates + Phase 9/10 analytics engines
    ├── opportunities.js        Phase 5 logic + rendering
    ├── learning.js             Phase 6 logic + rendering
    ├── applications.js          Phase 8 application review logic + rendering
    ├── industry.js              Phase 8 profile/opportunity CRUD/candidates
    ├── insights.js              Phase 9/10 rendering (Academician/Institution)
    ├── app-student.js           student.html page controller
    ├── app-industry.js          industry.html page controller
    ├── app-academician.js       academician.html page controller
    └── app-institution.js       institution.html page controller
```

## Migration map

| Streamlit feature | Web equivalent |
|---|---|
| `st.session_state` | `localStorage`, namespaced per logged-in user id (`storage.js`) |
| `pages/login.py`, `modules/auth/*` | `login.html`, `register.html`, `js/auth.js` (SHA-256 via Web Crypto) |
| `components/sidebar.py` | `js/navigation.js` (sidebar + tab shell, built per role) |
| `components/cards.py`, `*_cards.py` | `js/ui.js` (reusable card/badge/progress-bar/toast renderers) |
| `modules/student/profile.py`, `skills.py`, `portfolio.py` | `js/app-student.js` (profile / skills / portfolio tabs) |
| `modules/student/assessment.py` + `data/assessment_questions.py` | `Assessment` in `js/engine.js` (scoring) + `app-student.js` (question flow UI) |
| `modules/student/skill_gap.py` + `data/job_roles.py`, `industry_skills.py` | `SkillGap` in `js/engine.js` |
| `modules/student/opportunities.py` + `data/opportunities.py` | `js/opportunities.js` |
| `modules/student/learning.py` + `data/learning_resources.py` | `js/learning.js` |
| `modules/matching/opportunity_matcher.py` | `Matcher` in `js/engine.js` |
| `modules/student/smart_recommendations.py` | `renderSmartRecommendations()` in `js/app-student.js` |
| `modules/industry/profile.py`, `opportunities.py` | `js/industry.js` |
| `modules/industry/candidates.py` + `data/candidates.py` | `Candidates` in `js/analytics-engine.js` |
| `modules/industry/applications.py` | `js/applications.js` |
| `modules/analytics/data.py`, `metrics.py` | `AnalyticsData`, `AnalyticsMetrics` in `js/analytics-engine.js` |
| `modules/analytics/department_domain.py` | `DepartmentDomain` in `js/analytics-engine.js` |
| `modules/collaboration/curriculum_intelligence.py` + `data/curriculum.py` | `CurriculumIntelligence` in `js/analytics-engine.js` |
| `modules/collaboration/collaboration_engine.py` | `CollaborationEngine` in `js/analytics-engine.js` |
| `modules/analytics/dashboard.py`, `modules/collaboration/dashboard.py` | `js/insights.js` (rendering, shared by Academician/Institution) |
| `pages/student.py`, `industry.py`, `academician.py`, `institution.py` | `js/app-student.js`, `app-industry.js`, `app-academician.js`, `app-institution.js` |

## Authentication & data storage

- Passwords are hashed with SHA-256 via the browser's **Web Crypto API**
  before being stored — matching the original's `hashlib.sha256` approach.
- **Prototype authentication uses browser-side storage and is not suitable
  for production.** There is no real backend or server-side validation.
- All mutable app data (profiles, skills, applications, posted
  opportunities, etc.) lives in `localStorage`, namespaced by the logged-in
  user's numeric id (e.g. `aisb:u1:student_profile`), so two different
  demo accounts used in the same browser never see each other's data.
- Static reference/sample data (job roles, the opportunity catalog, learning
  resources, the mock candidate roster, curriculum courses, assessment
  questions) lives in `js/data.js`, generated once from the original
  `data/*.py` files — this mirrors using JSON files, just inlined as a JS
  constant so the site also works without a server that can serve `.json`
  with the right MIME type.

## Role-based access control

Every dashboard page calls `Auth.requireRole([...])` on load:
- Not logged in → redirected to `login.html`.
- Logged in as the wrong role → shown "Access denied" and redirected to
  their own dashboard.

## Preserved business logic (Phases 3, 4, 7, 9, 10)

The scoring engines were ported **formula-for-formula** from the Python
source, including every threshold and weight constant:

- **Skill Assessment** — same proficiency thresholds (80/60/40) and
  strength cutoff (80).
- **Skill Gap Engine** — same gap thresholds, priority thresholds, and
  readiness-score formula.
- **Smart Opportunity Matching** — the exact weighted formula from the
  spec: `Required Skill Alignment × 0.50 + Preferred Skill Alignment ×
  0.10 + Target Role Relevance × 0.25 + Skill Gap Relevance × 0.15`, with
  the same 80/65/50 match-category cutoffs.
- **Phase 9 Analytics** — same Skill Priority Score weights
  (demand 0.50 / gap 0.30 / shortage 0.20) and supply-demand thresholds.
- **Phase 10 Curriculum Intelligence & Collaboration Engine** — same
  Academic Priority weights (demand 0.40 / gap 0.30 / shortage 0.20 /
  coverage deficiency 0.10) and Collaboration Score weights (demand
  relevance 0.40 / gap relevance 0.30 / curriculum relevance 0.20 /
  activity 0.10).

## Testing performed

Automated end-to-end testing was run with Playwright (headless Chromium)
against a local static server, covering:

- **Authentication:** register a new account, log in with all four demo
  accounts, logout, and role-based access control (a Student account
  attempting to open `industry.html` directly is redirected back with an
  access-denied alert).
- **Student:** every tab visited; profile saved; a technical skill added;
  the full 28-question assessment answered and scored; a skill-gap
  analysis run; an opportunity viewed, saved, and applied to; a learning
  resource viewed and started; smart recommendations rendered; a
  portfolio project added.
- **Industry:** every tab visited; company profile saved; a new
  opportunity posted and managed; an application shortlisted; a candidate
  profile viewed; talent discovery run against a posted opportunity.
- **Academician / Institution:** every tab visited (skill analytics,
  curriculum intelligence, training priorities, collaboration
  opportunities, reports).
- **Data isolation:** two different Student accounts in the same browser
  were confirmed to have completely separate `technical_skills` (and by
  the same namespaced-storage mechanism, every other piece of session
  data).

**Result:** all scenarios passed with zero browser console errors and zero
uncaught JavaScript exceptions.

Browser DevTools should show no `Uncaught ReferenceError`,
`Uncaught TypeError`, `SyntaxError`, or failed resource loads.

## Responsive design

`css/style.css` includes media queries for tablet and mobile: below 720px
the sidebar collapses behind a hamburger toggle, and grids drop from
2–4 columns down to a single column.

## Known limitations

- This is a **frontend-only prototype**. There is no real backend, no
  server-side validation, and `localStorage` is per-browser — clearing
  site data or switching browsers loses everything.
- Authentication is not production-grade (see the note above).
- A few very small, purely cosmetic Streamlit-only details (e.g. exact
  `st.expander` behavior) were adapted to plain cards/sections rather than
  reproduced pixel-for-pixel, since Streamlit's widget chrome has no direct
  HTML equivalent — no functionality was removed.
- The original Python/Streamlit files under `academia_industry_portal/`
  (the source project) have been left untouched, per the migration
  instructions, so they can be removed later once you've confirmed this
  version fully replaces them.

## Phase 1–12 status

All twelve phases are present and functional in this web version: project
foundation & dashboards (1), student profile/skills/portfolio (2),
skill assessment (3), skill-gap analysis (4), opportunity portal (5),
learning recommendations (6), smart matching (7), industry/recruiter
portal (8), skill demand & academia analytics (9), curriculum
intelligence & collaboration (10), authentication & role-based access
(11), and per-user data linking & access control (12).

---

# Phase 13 — Real-Time Industry Data Integration

## Purpose

Replace purely static/demo industry data with a modular system capable of
receiving frequently updated job-market data through legitimate APIs,
without ever exposing API keys/secrets in the frontend and without
scraping or bypassing any platform's authentication (LinkedIn included).

## Architecture

```
FRONTEND (unchanged: HTML/CSS/vanilla JS)
   |
   ↓  js/api/apiClient.js  (only talks to OUR backend, holds no secrets)
   ↓
BACKEND — backend/server.js (Node, built-in http module, zero npm deps)
   |
   ├── providers/linkedinProvider.js   (OAuth-ready, official LinkedIn APIs only)
   ├── providers/jobMarketProvider.js  (Remotive — real, public, keyless job API)
   └── providers/mockProvider.js       (bundled demo data — always available)
         ↓
   services/dataNormalizer.js   (one common job shape + freshness label)
   services/cacheService.js     (in-memory cache, last-good fallback)
         ↓
   routes: /api/jobs, /api/industry/trends, /api/industry/status, /api/skills/*
         ↓
FRONTEND DASHBOARDS — js/live-industry.js feeds the EXISTING Phase 9
(AnalyticsMetrics) and Phase 10 (CurriculumIntelligence) engines rather
than duplicating them.
```

**No dependency install required.** The backend is written against only
Node's built-in `http` module (`npm install` has nothing to fetch), so it
can't break from a missing/incompatible npm package.

## Backend setup

```
cd backend
cp .env.example .env      # already done for you — DEMO_MODE=true out of the box
npm start                 # or: node server.js
```

The API now listens on `http://localhost:3000`. Any `http://localhost:*`
or `http://127.0.0.1:*` origin is allowed automatically in development
(covers Live Server, `python -m http.server`, etc. regardless of port) —
see `CORS_ORIGIN` in `.env` if you need to lock this down.

## Environment variables (`backend/.env`)

| Variable | Purpose |
|---|---|
| `PORT` | Backend port (default `3000`). |
| `CORS_ORIGIN` | Extra allowed origins beyond localhost, comma-separated. |
| `DEMO_MODE` | `true` (default) → always use bundled mock data. `false` → try LinkedIn, then the Job Market API, then fall back to mock. |
| `LINKEDIN_CLIENT_ID` / `LINKEDIN_CLIENT_SECRET` / `LINKEDIN_ACCESS_TOKEN` | Leave blank until you have an **approved LinkedIn API product** and OAuth token from LinkedIn's own developer portal. With these blank, the status page correctly reports "Not Configured" and the system falls through to the next provider — nothing is faked. |
| `JOB_MARKET_API_BASE_URL` | Defaults to Remotive's public, keyless job-listings API — a real, legally available data source used when LinkedIn isn't approved. |
| `FRESHNESS_LIVE_MINUTES` / `FRESHNESS_RECENT_MINUTES` | Freshness thresholds (see below). |
| `CACHE_TTL_MINUTES` | How long a successful fetch is served from cache before the next request triggers a refetch. |
| `NODE_ENV` | `production` disables verbose error detail in API responses and stops auto-allowing all localhost CORS origins. |

`.env` is git-ignored; `.env.example` (checked in) contains only empty
placeholders for anything secret.

**No secret ever reaches the frontend.** `js/api/apiClient.js` only ever
calls our own backend at `http://localhost:3000` — never LinkedIn or any
other external API directly, and it holds no keys.

## Demo Mode

With `DEMO_MODE=true` (the shipped default), every request is served from
`backend/data/mockJobs.json`, clearly labeled `"source": "mock"` and shown
in the UI as **● MOCK** — never `LIVE`. This lets you demo the whole
project with zero external API approval. Set `DEMO_MODE=false` once you
have real credentials to enable the LinkedIn → Job Market API → Mock
fallback chain.

## LinkedIn integration

`backend/providers/linkedinProvider.js` is a ready-to-configure client for
**LinkedIn's own official REST APIs only** — OAuth 2.0 token handling,
timeout, retry, and rate-limit handling are all implemented. It does not
scrape LinkedIn, use unofficial endpoints, or bypass authentication. Until
an approved LinkedIn API product and access token are configured, it
returns a clear `"LinkedIn integration not approved"` result and the
system automatically uses the next configured provider — it never
fabricates a LinkedIn response.

## Freshness model

Every job record carries `sourceUpdatedAt`, `fetchedAt`, and a computed
`freshness`:

| Status | Meaning |
|---|---|
| `LIVE` | Fetched from a real provider, updated < 10 minutes ago |
| `RECENT` | Real provider, 10–60 minutes ago |
| `STALE` | Real provider, > 60 minutes ago |
| `MOCK` | Bundled demo data — never shown as LIVE/RECENT/STALE |
| `ERROR` | No data could be fetched or served from cache at all |

Thresholds are configurable via `FRESHNESS_LIVE_MINUTES` /
`FRESHNESS_RECENT_MINUTES`.

## Auto-refresh & caching

The frontend (`js/live-industry.js`) refreshes every 5 minutes by default
and exposes a manual **🔄 Refresh** button on every live-data section. The
backend caches the last successful response (`CACHE_TTL_MINUTES`, default
5) so repeated dashboard visits don't hammer the external API, and — if
every provider fails on a given request — serves the last known-good
cached response with a clear "showing cached data" note instead of an
empty dashboard.

## Where live data shows up

- **Student dashboard** — "📈 Current Industry Demand" section comparing
  live top skills against the student's own profile.
- **Industry → Industry Analytics tab** — live opportunity/skill-demand
  section at the top, above the existing posted-opportunities analytics.
- **Academician → new "Live Industry Alignment" tab** — live industry
  skills vs. current curriculum coverage (reuses the Phase 10 engine).
- **Institution → new "Live Industry Demand" tab** — filterable by
  location, industry, and skill.
- **`api-status.html`** (linked from every sidebar) — provider/cache
  health for all four data sources. Never displays any key, secret, or
  token.

## Reused, not duplicated

`js/live-industry.js` converts live job records into the same
`{required_skills, preferred_skills}` shape Phase 5 opportunities already
use, then calls the *existing* `AnalyticsMetrics.calculateSkillDemand()`
(Phase 9) and `CurriculumIntelligence.calculateCurriculumCoverage()`
(Phase 10) — there is no second, independent analytics engine. The Phase
7 matching formula and its weights are completely untouched.

## Limitations

- This remains a **local development setup** — the "backend" has no
  database, just an in-memory cache that resets on restart. Fine for a
  college demo; would need a real datastore for production history/trend
  analysis (spec point 24 lists the suggested tables for that future work).
- Growth/trend percentages are intentionally **not fabricated**: without
  historical data the UI honestly shows "Trend unavailable — collecting
  baseline data" rather than inventing a number.
- Live data availability depends entirely on the permissions, products,
  and rate limits of whichever API providers you configure — LinkedIn
  access in particular requires their approval process, which this app
  cannot bypass or substitute for.

## Testing performed (Phase 13 additions)

Extended the existing Playwright end-to-end suite to also cover, with the
real backend running:
- All `/api/jobs`, `/api/industry/trends`, `/api/industry/status`,
  `/api/skills/demand` endpoints in both Demo Mode and live mode (the
  LinkedIn → Job Market API → Mock fallback chain was verified with
  network access blocked, confirming it degrades to mock data cleanly).
- Every new dashboard section (Student, Industry, Academician,
  Institution) rendering real data from the backend, including the
  Institution live-demand filters and the manual refresh button.
- `api-status.html` reachability and content.
- **Backend completely offline**: confirmed zero page errors and a clear
  "temporarily unavailable" message on every live-data section — the
  rest of the site (everything from Phases 1–12) continues to work
  normally.

All scenarios passed with zero browser console errors and zero uncaught
JavaScript exceptions.

## Running the full project

```
Backend:
cd backend && npm start        → http://localhost:3000

Frontend:
Open the project folder in VS Code → right-click index.html → "Open with Live Server"
                                 → http://127.0.0.1:5500 (or whatever port Live Server picks)
```

