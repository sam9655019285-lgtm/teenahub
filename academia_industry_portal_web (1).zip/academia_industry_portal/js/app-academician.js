/*
 * app-academician.js — page controller for academician.html (Phase 9/10).
 */
document.addEventListener("DOMContentLoaded", () => {
  if (!Auth.requireRole(["Academician"])) return;
  Storage.ensureAllInitialized();
  Navigation.renderShell("Academician");
  buildPanels();
  window.addEventListener("tab-activated", (e) => onTabActivated(e.detail.tabId));
  Navigation.activateTab("dashboard");

  let currentTab = "dashboard";
  window.addEventListener("tab-activated", (e) => { currentTab = e.detail.tabId; });
  LiveIndustry.onUpdate(() => {
    if (currentTab === "live-alignment") {
      const el = document.getElementById("content-live-alignment");
      if (el) LiveIndustry.renderAcademicianLiveAlignment(el);
    }
  });
  LiveIndustry.refresh();
  LiveIndustry.startAutoRefresh();
});

function buildPanels() {
  const main = document.getElementById("main-content");
  const tabs = ["dashboard", "skill-analytics", "curriculum", "live-alignment", "training", "collaboration"];
  main.innerHTML = tabs.map((id) => `<div class="tab-panel" id="panel-${id}"><div id="content-${id}"></div></div>`).join("");
}

function onTabActivated(tabId) {
  const el = document.getElementById(`content-${tabId}`);
  if (!el) return;
  switch (tabId) {
    case "dashboard": renderAcademicianDashboard(el); break;
    case "skill-analytics": Insights.renderSkillAnalytics(el, "Industry Demand & Student Skill Gaps"); break;
    case "curriculum": Insights.renderCurriculum(el); break;
    case "live-alignment": LiveIndustry.renderAcademicianLiveAlignment(el); break;
    case "training": Insights.renderTraining(el); break;
    case "collaboration": Insights.renderCollaboration(el); break;
  }
}

function renderAcademicianDashboard(container) {
  const user = Auth.getCurrentUser();
  const alignment = CurriculumIntelligence.calculateCurriculumAlignment();
  const priority = AnalyticsMetrics.calculateSkillPriority();
  const topSkill = Object.keys(priority)[0];
  const collab = CollaborationEngine.calculateAllCollaborationScores();

  container.innerHTML = `
    <div class="page-header"><h1>Welcome, ${UI.escapeHtml(user.name)}</h1><p>Academic insights across industry demand, student skill gaps, and curriculum alignment.</p></div>
    ${UI.metricRow([
      ["Curriculum Alignment", `${alignment.alignment_score}%`],
      ["Top Priority Skill", topSkill || "—"],
      ["Collaboration Candidates", collab.length],
      ["Tracked Students", AnalyticsData.getStudentPopulation().length],
    ])}
    <div id="dash-dept"></div>
  `;
  Insights.renderDepartmentInsights(document.getElementById("dash-dept"));
}
