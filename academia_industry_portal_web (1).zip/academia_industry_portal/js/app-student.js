/*
 * app-student.js — page controller for student.html.
 * Wires Phases 1-7 (profile, skills, portfolio, assessment, skill
 * gap, opportunities, learning, smart recommendations) into the tab
 * shell built by navigation.js.
 */

const TECHNICAL_SKILL_OPTIONS = ["Python", "Java", "C++", "SQL", "Machine Learning", "Data Analysis", "Git", "Cloud"];
const SOFT_SKILL_OPTIONS = ["Communication", "Problem Solving", "Leadership", "Teamwork", "Time Management"];
const PROFICIENCY_LEVELS = ["Beginner", "Intermediate", "Advanced"];

document.addEventListener("DOMContentLoaded", () => {
  if (!Auth.requireRole(["Student"])) return;
  Storage.initStudentData();
  Navigation.renderShell("Student");
  buildPanels();
  window.addEventListener("tab-activated", (e) => onTabActivated(e.detail.tabId));
  Navigation.activateTab("dashboard");

  // Phase 13 — live industry data. Fetch once, auto-refresh every 5
  // minutes, and re-render the dashboard's live widget whenever new
  // data arrives if the student is currently looking at it.
  let currentTab = "dashboard";
  window.addEventListener("tab-activated", (e) => { currentTab = e.detail.tabId; });
  LiveIndustry.onUpdate(() => {
    if (currentTab === "dashboard") {
      const widget = document.getElementById("dash-industry-demand");
      if (widget) LiveIndustry.renderStudentDemandWidget(widget);
    }
  });
  LiveIndustry.refresh();
  LiveIndustry.startAutoRefresh();
});

function buildPanels() {
  const main = document.getElementById("main-content");
  const tabs = [
    "dashboard", "profile", "skills", "portfolio", "assessment", "skillgap",
    "opportunities", "saved-opps", "applications", "learning", "recommended-learning",
    "saved-learning", "my-learning", "smart-recommendations",
  ];
  main.innerHTML = tabs.map((id) => `<div class="tab-panel" id="panel-${id}"><div id="content-${id}"></div></div>`).join("");
}

function onTabActivated(tabId) {
  const el = document.getElementById(`content-${tabId}`);
  if (!el) return;
  switch (tabId) {
    case "dashboard": renderDashboard(el); break;
    case "profile": renderProfileTab(el); break;
    case "skills": renderSkillsTab(el); break;
    case "portfolio": renderPortfolioTab(el); break;
    case "assessment": renderAssessmentTab(el); break;
    case "skillgap": renderSkillGapTab(el); break;
    case "opportunities": Opportunities.renderSection(el); break;
    case "saved-opps": Opportunities.renderSaved(el); break;
    case "applications": Opportunities.renderApplications(el); break;
    case "learning": Learning.renderSection(el); break;
    case "recommended-learning": Learning.renderRecommendations(el); break;
    case "saved-learning": Learning.renderSaved(el); break;
    case "my-learning": Learning.renderMyLearning(el); break;
    case "smart-recommendations": renderSmartRecommendations(el); break;
  }
}

// ============================================================
// Dashboard (Phase 1 + summary cards from every phase)
// ============================================================
function getProfileCompletionPercentage() {
  const profile = Storage.get("student_profile", {});
  const personal = !!profile.full_name && !!profile.email;
  const academic = !!profile.college_name && !!profile.degree;
  const career = !!profile.target_job_role;
  const tech = Object.keys(Storage.get("technical_skills", {})).length > 0;
  const soft = Object.keys(Storage.get("soft_skills", {})).length > 0;
  const projects = Storage.get("projects", []).length > 0;
  const done = [personal, academic, career, tech, soft, projects].filter(Boolean).length;
  return Math.round((done / 6) * 100);
}

function renderDashboard(container) {
  const user = Auth.getCurrentUser();
  const completion = getProfileCompletionPercentage();
  const assessmentResult = Storage.get("assessment_result", null);
  const gapAnalysis = Storage.get("skill_gap_analysis", null);

  container.innerHTML = `
    <div class="page-header"><h1>Academia–Industry Collaboration Portal</h1><p>Welcome back, ${UI.escapeHtml(user.name)}. Here's your snapshot.</p></div>
    ${UI.sectionHeader("Profile Completion")}
    ${UI.progressBar(completion, UI.progressColorForScore(completion))}
    <p class="muted">${completion}% complete</p>
    <hr class="divider">
    <div class="grid grid-2">
      <div class="card">${UI.sectionHeader("Skill Assessment")}${assessmentResult
        ? UI.metricRow([["Overall Score", `${assessmentResult.overall_score}%`], ["Proficiency", assessmentResult.overall_level]])
        : `<p class="muted">Not completed yet. Open the Skill Assessment tab above to take it.</p>`}</div>
      <div class="card" id="dash-gap-card"></div>
    </div>
    <div id="dash-opps"></div>
    <div id="dash-learning"></div>
    <hr class="divider">
    <div id="dash-industry-demand"></div>
  `;

  const gapCard = document.getElementById("dash-gap-card");
  gapCard.innerHTML = UI.sectionHeader("Industry Skill Gap");
  if (!assessmentResult) {
    gapCard.innerHTML += `<p class="muted">Complete your Skill Assessment to generate your Industry Skill Gap Analysis.</p>`;
  } else if (!gapAnalysis) {
    gapCard.innerHTML += `<p class="muted">Select a target career in the Skill Gap Analysis tab to see your readiness.</p>`;
  } else {
    const majorGaps = Object.values(gapAnalysis.skills).filter((d) => d.status === "Major Gap").length;
    gapCard.innerHTML += UI.metricRow([["Readiness", `${gapAnalysis.readiness_score}%`], ["Target Role", gapAnalysis.target_role], ["Major Gaps", majorGaps]]);
    if (gapAnalysis.priority_gaps.length) gapCard.innerHTML += `<p><strong>Top Skill Gap:</strong> ${UI.escapeHtml(gapAnalysis.priority_gaps[0].skill)}</p>`;
  }

  Opportunities.renderDashboardSummary(document.getElementById("dash-opps"));
  Learning.renderDashboardSummary(document.getElementById("dash-learning"));
  LiveIndustry.renderStudentDemandWidget(document.getElementById("dash-industry-demand"));
}

// ============================================================
// Phase 2 — Profile
// ============================================================
function renderProfileTab(container) {
  const p = Storage.get("student_profile", {});
  container.innerHTML = `
    <h3>My Profile</h3>
    <form id="profile-form">
      <fieldset><legend>Personal Information</legend>
        <label>Full Name</label><input type="text" id="pf-name" value="${UI.escapeHtml(p.full_name || "")}">
        <label>Email</label><input type="text" id="pf-email" value="${UI.escapeHtml(p.email || "")}">
        <label>Phone Number</label><input type="text" id="pf-phone" value="${UI.escapeHtml(p.phone_number || "")}">
        <label>Location</label><input type="text" id="pf-location" value="${UI.escapeHtml(p.location || "")}">
      </fieldset>
      <fieldset><legend>Academic Information</legend>
        <label>College/Institution</label><input type="text" id="pf-college" value="${UI.escapeHtml(p.college_name || "")}">
        <label>Degree</label><input type="text" id="pf-degree" value="${UI.escapeHtml(p.degree || "")}">
        <label>Department</label><input type="text" id="pf-department" value="${UI.escapeHtml(p.department || "")}">
        <label>Current Year</label><select id="pf-year">${UI.selectOptions(["1st Year", "2nd Year", "3rd Year", "4th Year"], p.current_year, false)}</select>
        <label>CGPA</label><input type="number" id="pf-cgpa" min="0" max="10" step="0.01" value="${p.cgpa || 0}">
      </fieldset>
      <fieldset><legend>Career Information</legend>
        <label>Career Interests</label><input type="text" id="pf-interests" value="${UI.escapeHtml(p.career_interests || "")}" placeholder="Example: Data Science, Web Development, Cloud Computing">
        <label>Target Job Role</label><input type="text" id="pf-target-role" value="${UI.escapeHtml(p.target_job_role || "")}">
        <label>Preferred Industry</label><input type="text" id="pf-industry" value="${UI.escapeHtml(p.preferred_industry || "")}">
      </fieldset>
      <button type="submit" class="btn btn-primary">Save Profile</button>
    </form>`;

  document.getElementById("profile-form").onsubmit = (e) => {
    e.preventDefault();
    Storage.set("student_profile", {
      full_name: document.getElementById("pf-name").value, email: document.getElementById("pf-email").value,
      phone_number: document.getElementById("pf-phone").value, location: document.getElementById("pf-location").value,
      college_name: document.getElementById("pf-college").value, degree: document.getElementById("pf-degree").value,
      department: document.getElementById("pf-department").value, current_year: document.getElementById("pf-year").value,
      cgpa: parseFloat(document.getElementById("pf-cgpa").value) || 0,
      career_interests: document.getElementById("pf-interests").value, target_job_role: document.getElementById("pf-target-role").value,
      preferred_industry: document.getElementById("pf-industry").value,
    });
    UI.toast("Profile saved successfully!", "success");
  };
}

// ============================================================
// Phase 2 — Skills
// ============================================================
function renderSkillsTab(container) {
  container.innerHTML = `
    <h3>My Skills</h3>
    <h4>Technical Skills</h4>
    <form id="add-tech-skill-form" class="grid grid-3" style="align-items:end;">
      <div><label>Skill</label><select id="tech-skill-select">${UI.selectOptions(TECHNICAL_SKILL_OPTIONS, null, false)}</select></div>
      <div><label>Proficiency</label><select id="tech-skill-level">${UI.selectOptions(PROFICIENCY_LEVELS, null, false)}</select></div>
      <div><button type="submit" class="btn btn-primary" style="margin-bottom:14px;">Add Skill</button></div>
    </form>
    <div id="tech-skill-list"></div>
    <hr class="divider">
    <h4>Soft Skills</h4>
    <form id="add-soft-skill-form" class="grid grid-3" style="align-items:end;">
      <div><label>Skill</label><select id="soft-skill-select">${UI.selectOptions(SOFT_SKILL_OPTIONS, null, false)}</select></div>
      <div><label>Proficiency</label><select id="soft-skill-level">${UI.selectOptions(PROFICIENCY_LEVELS, null, false)}</select></div>
      <div><button type="submit" class="btn btn-primary" style="margin-bottom:14px;">Add Skill</button></div>
    </form>
    <div id="soft-skill-list"></div>`;

  function renderList(key, listElId) {
    const skills = Storage.get(key, {});
    const el = document.getElementById(listElId);
    const entries = Object.entries(skills);
    el.innerHTML = entries.length ? entries.map(([name, level]) => `
      <div class="card-row card" style="padding:10px 14px;">
        <span>${UI.escapeHtml(name)}</span><span>${UI.escapeHtml(level)}</span>
        <button class="btn btn-sm btn-danger remove-skill-btn" data-skill="${UI.escapeHtml(name)}">Remove</button>
      </div>`).join("") : `<p class="muted">No skills added yet.</p>`;
    el.querySelectorAll(".remove-skill-btn").forEach((btn) => btn.onclick = () => {
      const s = Storage.get(key, {});
      delete s[btn.dataset.skill];
      Storage.set(key, s);
      renderList(key, listElId);
    });
  }

  document.getElementById("add-tech-skill-form").onsubmit = (e) => {
    e.preventDefault();
    const s = Storage.get("technical_skills", {});
    s[document.getElementById("tech-skill-select").value] = document.getElementById("tech-skill-level").value;
    Storage.set("technical_skills", s);
    UI.toast("Skill added", "success");
    renderList("technical_skills", "tech-skill-list");
  };
  document.getElementById("add-soft-skill-form").onsubmit = (e) => {
    e.preventDefault();
    const s = Storage.get("soft_skills", {});
    s[document.getElementById("soft-skill-select").value] = document.getElementById("soft-skill-level").value;
    Storage.set("soft_skills", s);
    UI.toast("Skill added", "success");
    renderList("soft_skills", "soft-skill-list");
  };

  renderList("technical_skills", "tech-skill-list");
  renderList("soft_skills", "soft-skill-list");
}

// ============================================================
// Phase 2 — Portfolio (projects & certifications)
// ============================================================
function renderPortfolioTab(container) {
  container.innerHTML = `
    <h3>Portfolio</h3>
    <h4>Projects</h4>
    <form id="add-project-form">
      <label>Project Name</label><input type="text" id="proj-name">
      <label>Short Description</label><textarea id="proj-desc"></textarea>
      <label>Technologies Used</label><input type="text" id="proj-tech" placeholder="Example: Python, Streamlit, SQL">
      <label>Project Link</label><input type="text" id="proj-link">
      <button type="submit" class="btn btn-primary">Add Project</button>
    </form>
    <div id="project-list"></div>
    <hr class="divider">
    <h4>Certifications</h4>
    <form id="add-cert-form">
      <label>Certification Name</label><input type="text" id="cert-name">
      <label>Issuing Organization</label><input type="text" id="cert-org">
      <label>Completion Year</label><input type="number" id="cert-year" min="2000" max="2100" value="2024">
      <label>Certificate Link</label><input type="text" id="cert-link">
      <button type="submit" class="btn btn-primary">Add Certification</button>
    </form>
    <div id="cert-list"></div>`;

  function renderProjects() {
    const projects = Storage.get("projects", []);
    const el = document.getElementById("project-list");
    el.innerHTML = projects.length ? projects.map((p, i) => `
      <div class="card">
        <div class="card-title">${UI.escapeHtml(p.project_name)}</div>
        <p>${UI.escapeHtml(p.project_description)}</p>
        ${p.technologies_used ? `<p><strong>Technologies:</strong> ${UI.escapeHtml(p.technologies_used)}</p>` : ""}
        ${p.project_link ? `<p><strong>Link:</strong> ${UI.escapeHtml(p.project_link)}</p>` : ""}
        <button class="btn btn-sm btn-danger remove-proj-btn" data-idx="${i}">Remove Project</button>
      </div>`).join("") : `<p class="muted">No projects added yet.</p>`;
    el.querySelectorAll(".remove-proj-btn").forEach((btn) => btn.onclick = () => {
      const list = Storage.get("projects", []);
      list.splice(Number(btn.dataset.idx), 1);
      Storage.set("projects", list);
      renderProjects();
    });
  }
  function renderCerts() {
    const certs = Storage.get("certifications", []);
    const el = document.getElementById("cert-list");
    el.innerHTML = certs.length ? certs.map((c, i) => `
      <div class="card">
        <div class="card-title">${UI.escapeHtml(c.certification_name)}</div>
        ${c.issuing_organization ? `<p><strong>Issued by:</strong> ${UI.escapeHtml(c.issuing_organization)}</p>` : ""}
        <p><strong>Completion Year:</strong> ${c.completion_year}</p>
        ${c.certificate_link ? `<p><strong>Link:</strong> ${UI.escapeHtml(c.certificate_link)}</p>` : ""}
        <button class="btn btn-sm btn-danger remove-cert-btn" data-idx="${i}">Remove Certification</button>
      </div>`).join("") : `<p class="muted">No certifications added yet.</p>`;
    el.querySelectorAll(".remove-cert-btn").forEach((btn) => btn.onclick = () => {
      const list = Storage.get("certifications", []);
      list.splice(Number(btn.dataset.idx), 1);
      Storage.set("certifications", list);
      renderCerts();
    });
  }

  document.getElementById("add-project-form").onsubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById("proj-name").value;
    if (!name.trim()) { UI.toast("Please enter a project name before adding.", "warning"); return; }
    const list = Storage.get("projects", []);
    list.push({ project_name: name, project_description: document.getElementById("proj-desc").value, technologies_used: document.getElementById("proj-tech").value, project_link: document.getElementById("proj-link").value });
    Storage.set("projects", list);
    UI.toast(`Added project: ${name}`, "success");
    e.target.reset();
    renderProjects();
  };
  document.getElementById("add-cert-form").onsubmit = (e) => {
    e.preventDefault();
    const name = document.getElementById("cert-name").value;
    if (!name.trim()) { UI.toast("Please enter a certification name before adding.", "warning"); return; }
    const list = Storage.get("certifications", []);
    list.push({ certification_name: name, issuing_organization: document.getElementById("cert-org").value, completion_year: Number(document.getElementById("cert-year").value), certificate_link: document.getElementById("cert-link").value });
    Storage.set("certifications", list);
    UI.toast(`Added certification: ${name}`, "success");
    e.target.reset();
    renderCerts();
  };

  renderProjects();
  renderCerts();
}

// ============================================================
// Phase 3 — Skill Assessment
// ============================================================
function renderAssessmentTab(container) {
  const questions = DATA.ASSESSMENT_QUESTIONS;
  if (!questions.length) { container.innerHTML = UI.emptyState("No assessment questions are available yet."); return; }

  if (Storage.get("assessment_started", false)) { renderQuestionFlow(container); return; }
  const result = Storage.get("assessment_result", null);
  if (result) { renderAssessmentResults(container); return; }
  renderAssessmentIntro(container);
}

function renderAssessmentIntro(container) {
  const questions = DATA.ASSESSMENT_QUESTIONS;
  const categories = Object.keys(DATA.CATEGORY_GROUPS);
  const estMinutes = Math.max(1, Math.round(questions.length * 0.75));
  container.innerHTML = `
    <h3>Skill Assessment</h3>
    <p>This assessment evaluates your current technical and soft skills and helps identify your strengths and areas for improvement.</p>
    ${UI.metricRow([["Questions", questions.length], ["Categories", categories.length], ["Est. Time", `~${estMinutes} min`]])}
    <p class="muted">Categories covered: ${categories.join(", ")}</p>
    ${Storage.get("assessment_result", null) ? `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">You've already completed this assessment once. Starting again will let you retake it.</div>` : ""}
    <button class="btn btn-primary" id="start-assessment-btn">Start Assessment</button>`;
  document.getElementById("start-assessment-btn").onclick = () => {
    Storage.set("assessment_answers", {});
    Storage.set("assessment_current_index", 0);
    Storage.set("assessment_attempt", (Storage.get("assessment_attempt", 0) || 0) + 1);
    Storage.set("assessment_started", true);
    renderAssessmentTab(container);
  };
}

function renderQuestionFlow(container) {
  const questions = DATA.ASSESSMENT_QUESTIONS;
  let index = Math.max(0, Math.min(Storage.get("assessment_current_index", 0), questions.length - 1));
  Storage.set("assessment_current_index", index);
  const question = questions[index];
  const answers = Storage.get("assessment_answers", {});
  const previousAnswer = answers[question.id];

  container.innerHTML = `
    <p class="muted">Question ${index + 1} / ${questions.length}</p>
    ${UI.progressBar(((index + 1) / questions.length) * 100)}
    <p><strong>Category:</strong> ${UI.escapeHtml(question.category)} &nbsp;•&nbsp; <strong>Difficulty:</strong> ${UI.escapeHtml(question.difficulty)}</p>
    <h4>${UI.escapeHtml(question.question)}</h4>
    <div id="assessment-options">${question.options.map((opt, i) => `
      <label style="display:flex;align-items:center;gap:8px;font-weight:400;margin-bottom:8px;">
        <input type="radio" name="assessment-opt" value="${UI.escapeHtml(opt)}" ${previousAnswer === opt ? "checked" : ""}> ${UI.escapeHtml(opt)}
      </label>`).join("")}</div>
    <hr class="divider">
    <div class="btn-row">
      <button class="btn" id="assessment-prev" ${index === 0 ? "disabled" : ""}>Previous</button>
      <button class="btn" id="assessment-next" ${index === questions.length - 1 ? "disabled" : ""}>Next</button>
      <button class="btn btn-primary" id="assessment-finish">Finish Assessment</button>
    </div>`;

  container.querySelectorAll('input[name="assessment-opt"]').forEach((input) => input.onchange = () => {
    const a = Storage.get("assessment_answers", {});
    a[question.id] = input.value;
    Storage.set("assessment_answers", a);
  });
  document.getElementById("assessment-prev").onclick = () => { Storage.set("assessment_current_index", index - 1); renderQuestionFlow(container); };
  document.getElementById("assessment-next").onclick = () => { Storage.set("assessment_current_index", index + 1); renderQuestionFlow(container); };
  document.getElementById("assessment-finish").onclick = () => {
    const finalAnswers = Storage.get("assessment_answers", {});
    const unanswered = questions.filter((q) => !(q.id in finalAnswers)).length;
    if (unanswered > 0) { UI.toast(`You have ${unanswered} unanswered question(s). Please answer every question before finishing.`, "warning"); return; }
    const result = Assessment.scoreAssessment(finalAnswers);
    Storage.set("assessment_result", result);
    Storage.set("assessment_started", false);
    renderAssessmentTab(document.getElementById("content-assessment"));
  };
}

function renderAssessmentResults(container) {
  const result = Storage.get("assessment_result");
  container.innerHTML = `
    <h3>Assessment Complete</h3>
    ${UI.metricRow([["Overall Score", `${result.overall_score}%`], ["Proficiency", result.overall_level], ["Skills Assessed", Object.keys(result.skill_scores).length]])}
    <hr class="divider">
    ${UI.sectionHeader("Skill Profile")}
    ${Object.entries(result.skill_scores).map(([name, score]) => `${UI.skillBar(name, score)}<p class="muted" style="margin-top:-8px;">${Assessment.getProficiencyLevel(score)}</p>`).join("")}
    <hr class="divider">
    <div class="grid grid-2">
      <div>${UI.sectionHeader("Strong Areas")}${result.strengths.length ? result.strengths.map(([n, s]) => `<div>🟢 ${UI.escapeHtml(n)} — ${s}%</div>`).join("") : `<span class="muted">No standout strengths yet — keep practicing!</span>`}</div>
      <div>${UI.sectionHeader("Areas to Improve")}${result.areas_to_improve.length ? result.areas_to_improve.map(([n, s]) => `<div>${s < 60 ? "🔴" : "🟡"} ${UI.escapeHtml(n)} — ${s}%</div>`).join("") : `<span class="muted">No weak areas identified — great work!</span>`}</div>
    </div>
    <hr class="divider">
    <button class="btn" id="retake-assessment-btn">Retake Assessment</button>`;
  document.getElementById("retake-assessment-btn").onclick = () => {
    Storage.set("assessment_answers", {});
    Storage.set("assessment_current_index", 0);
    Storage.set("assessment_attempt", (Storage.get("assessment_attempt", 0) || 0) + 1);
    Storage.set("assessment_started", true);
    renderAssessmentTab(container);
  };
}

// ============================================================
// Phase 4 — Skill Gap Analysis
// ============================================================
function renderSkillGapTab(container) {
  const roleNames = Object.keys(DATA.JOB_ROLES);
  container.innerHTML = `
    <h3>Skill Gap Analysis</h3>
    <p class="muted">An industry-alignment indicator based on defined skill requirements — not an official employment prediction.</p>
    <div id="skillgap-body"></div>`;
  const body = document.getElementById("skillgap-body");
  const assessmentResult = Storage.get("assessment_result", null);
  if (!assessmentResult) {
    body.innerHTML = `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">Complete your Skill Assessment to generate your Industry Skill Gap Analysis.</div>`;
    return;
  }

  const profile = Storage.get("student_profile", {});
  const savedTargetRole = Storage.get("skill_gap_target_role", null);
  const matchedFromProfile = SkillGap.matchProfileRole(profile.target_job_role || "", roleNames);
  const defaultRole = matchedFromProfile || (roleNames.includes(savedTargetRole) ? savedTargetRole : roleNames[0]);

  body.innerHTML = `
    <label>Select Target Career</label>
    <select id="sg-role-select">${UI.selectOptions(roleNames, defaultRole, false)}</select>
    <button class="btn btn-primary" id="sg-analyze-btn">Analyze Skill Gap</button>
    <div id="sg-results" style="margin-top:16px;"></div>`;

  Storage.set("skill_gap_target_role", defaultRole);
  document.getElementById("sg-role-select").onchange = (e) => Storage.set("skill_gap_target_role", e.target.value);

  document.getElementById("sg-analyze-btn").onclick = () => {
    const role = document.getElementById("sg-role-select").value;
    const currentProfile = SkillGap.getCurrentSkillProfile(Storage.get("technical_skills", {}), Storage.get("soft_skills", {}), assessmentResult);
    const analysis = SkillGap.analyzeSkillGap(role, currentProfile);
    Storage.set("skill_gap_analysis", analysis);
    renderGapResults();
  };

  function renderGapResults() {
    const analysis = Storage.get("skill_gap_analysis", null);
    const resultsEl = document.getElementById("sg-results");
    if (!analysis) { resultsEl.innerHTML = `<p class="muted">Select a target role and click Analyze Skill Gap to see your results.</p>`; return; }
    if (analysis.target_role !== document.getElementById("sg-role-select").value) {
      resultsEl.innerHTML = `<p class="muted">Target role changed — click Analyze Skill Gap to refresh your results.</p>`;
      return;
    }
    const meets = Object.entries(analysis.skills).filter(([, d]) => d.gap === 0).map(([n]) => n);
    const withGaps = Object.entries(analysis.skills).filter(([, d]) => d.gap > 0);

    resultsEl.innerHTML = UI.metricRow([["Target Role", analysis.target_role], ["Industry Readiness", `${analysis.readiness_score}%`]]) +
      `<hr class="divider"><div class="grid grid-2">
        <div>${UI.sectionHeader("Skills Meeting Requirement")}${meets.length ? meets.map((n) => `<div>🟢 ${UI.escapeHtml(n)}</div>`).join("") : `<span class="muted">None yet.</span>`}</div>
        <div>${UI.sectionHeader("Skills With Gaps")}${withGaps.length ? withGaps.map(([n, d]) => `<div>${SkillGap.STATUS_EMOJI[d.status] || ""} ${UI.escapeHtml(n)}</div>`).join("") : `<span class="muted">None — great alignment!</span>`}</div>
      </div><hr class="divider">` +
      UI.sectionHeader("Skill Analysis") +
      Object.entries(analysis.skills).map(([name, d]) => `
        <div class="card">
          <div class="card-title">${UI.escapeHtml(name)}${!d.has_data ? ` <span class="muted" style="font-weight:400;">(no data yet — treated as 0)</span>` : ""}</div>
          <div>${d.current} / ${d.required}</div>
          <div>${SkillGap.STATUS_EMOJI[d.status] || ""} ${UI.badge(d.status, UI.gapStatusKind(d.status))}</div>
        </div>`).join("") +
      `<hr class="divider">` + UI.sectionHeader("Your Priority Skill Gaps") +
      (analysis.priority_gaps.length
        ? `<ol>${analysis.priority_gaps.map((g) => `<li><strong>${UI.escapeHtml(g.skill)}</strong> — Gap: ${g.gap} points — Priority: ${UI.escapeHtml(g.priority_level)}</li>`).join("")}</ol>`
        : `<div class="auth-success">No significant skill gaps for this role. Great alignment!</div>`);
  }

  if (savedTargetRole === defaultRole) renderGapResults();
  else document.getElementById("sg-results").innerHTML = `<p class="muted">Select a target role and click Analyze Skill Gap to see your results.</p>`;
}

// ============================================================
// Phase 7 — Smart Recommendations
// ============================================================
function renderSmartRecommendations(container) {
  const knownRoles = Object.keys(DATA.JOB_ROLES);
  const targetRole = SkillGap.getEffectiveTargetRole(knownRoles, Storage.get("skill_gap_target_role", null), (Storage.get("student_profile", {}).target_job_role || ""));
  const profile = Opportunities.currentProfile();
  const gapAnalysis = Storage.get("skill_gap_analysis", null);
  const skillGapNames = gapAnalysis ? gapAnalysis.priority_gaps.map((g) => g.skill) : [];
  const opportunities = Opportunities.loadOpportunities().filter((o) => (o.status || "Active") === "Active");

  container.innerHTML = UI.sectionHeader("Smart Recommendations", "A transparent, rule-based engine combining skill alignment, role relevance, and your current skill gaps.");

  if (!targetRole) {
    container.innerHTML += `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">Set a Target Job Role in My Profile (or run a Skill Gap Analysis) to unlock personalized recommendations.</div>`;
    return;
  }

  const ranked = Matcher.getRecommendedOpportunities(opportunities, profile, targetRole, skillGapNames, 5);
  container.innerHTML += `<p><strong>Target Role:</strong> ${UI.escapeHtml(targetRole)}</p><hr class="divider">` +
    UI.sectionHeader("Top Matching Opportunities") +
    (ranked.length ? ranked.map((r) => {
      const opp = opportunities.find((o) => o.id === r.opportunity_id);
      return `<div class="card">
        <div class="card-row"><div class="card-title">${UI.escapeHtml(opp.title)}</div>${UI.badge(r.match_category, UI.matchBadgeKind(r.match_category))}</div>
        <div class="card-sub">${UI.escapeHtml(opp.company)}</div>
        ${UI.progressBar(r.match_score, UI.progressColorForScore(r.match_score))}
        <p style="font-size:.85rem;">Match Score: <strong>${r.match_score}%</strong> · Skill Alignment: ${r.skill_alignment}% · Role Relevance: ${r.role_relevance}</p>
        <ul class="list-clean" style="font-size:.84rem;">${r.reasons.map((reason) => `<li>✓ ${UI.escapeHtml(reason)}</li>`).join("")}</ul>
        <button class="btn btn-primary btn-sm view-opp-btn" data-id="${opp.id}">View Details</button>
      </div>`;
    }).join("") : UI.emptyState("No opportunities available yet."));

  container.querySelectorAll(".view-opp-btn").forEach((btn) => btn.onclick = () => { Storage.set("selected_opportunity_id", Number(btn.dataset.id)); Navigation.activateTab("opportunities"); });
}
