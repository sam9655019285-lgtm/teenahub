/*
 * app-institution.js — page controller for institution.html (Phase 9/10).
 */
document.addEventListener("DOMContentLoaded", () => {
  if (!Auth.requireRole(["Institution"])) return;
  Storage.ensureAllInitialized();
  Navigation.renderShell("Institution");
  buildPanels();
  window.addEventListener("tab-activated", (e) => onTabActivated(e.detail.tabId));
  Navigation.activateTab("dashboard");

  let currentTab = "dashboard";
  window.addEventListener("tab-activated", (e) => { currentTab = e.detail.tabId; });
  LiveIndustry.onUpdate(() => {
    if (currentTab === "live-demand") {
      const el = document.getElementById("content-live-demand");
      if (el) LiveIndustry.renderInstitutionLiveSection(el);
    }
  });
  LiveIndustry.refresh();
  LiveIndustry.startAutoRefresh();
});

function buildPanels() {
  const main = document.getElementById("main-content");
  const tabs = ["dashboard", "live-demand", "curriculum", "training", "collaboration", "reports"];
  main.innerHTML = tabs.map((id) => `<div class="tab-panel" id="panel-${id}"><div id="content-${id}"></div></div>`).join("");
}

function onTabActivated(tabId) {
  const el = document.getElementById(`content-${tabId}`);
  if (!el) return;
  switch (tabId) {
    case "dashboard": renderInstitutionDashboard(el); break;
    case "live-demand": LiveIndustry.renderInstitutionLiveSection(el); break;
    case "curriculum": Insights.renderCurriculum(el); break;
    case "training": Insights.renderTraining(el); break;
    case "collaboration": Insights.renderCollaboration(el); break;
    case "reports": Insights.renderReports(el); break;
  }
}

function renderInstitutionDashboard(container) {
  const user = Auth.getCurrentUser();
  container.innerHTML = `<div class="page-header"><h1>Welcome, ${UI.escapeHtml(user.name)}</h1><p>Overall analytics across every tracked skill, student, and industry partner.</p></div><div id="inst-overview"></div>`;
  Insights.renderSkillAnalytics(document.getElementById("inst-overview"), "Overall Skill Demand & Supply Analytics");
}
