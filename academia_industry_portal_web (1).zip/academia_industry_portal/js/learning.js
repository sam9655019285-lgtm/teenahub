/*
 * learning.js — Phase 6, ported from modules/student/learning.py.
 */

const Learning = (() => {
  const CATEGORY_ORDER = ["Highly Recommended", "Recommended", "Useful", "Not Priority"];
  const RECOMMENDATION_LIMIT = 6;

  function loadLearningResources() { return DATA.LEARNING_RESOURCES; }
  function getResourceById(resources, id) { return resources.find((r) => r.id === id) || null; }

  function searchResources(resources, query) {
    const q = (query || "").trim().toLowerCase();
    if (!q) return resources;
    return resources.filter((r) => [r.title, r.provider, r.domain, ...r.skills].some((v) => v.toLowerCase().includes(q)));
  }

  function filterResources(resources, filters) {
    let results = resources;
    const map = { type: "type", domain: "domain", level: "level", mode: "mode", cost: "cost" };
    for (const [k, field] of Object.entries(map)) {
      const val = filters[k];
      if (val && val !== "All") results = results.filter((r) => r[field] === val);
    }
    return results;
  }

  function getEffectiveTargetRole() {
    const knownRoles = Object.keys(DATA.ROLE_DOMAIN_RECOMMENDATIONS);
    const skillGapRole = Storage.get("skill_gap_target_role", null);
    const profile = Storage.get("student_profile", {});
    return SkillGap.getEffectiveTargetRole(knownRoles, skillGapRole, profile.target_job_role || "");
  }

  function getCurrentSkillGapNames() {
    const analysis = Storage.get("skill_gap_analysis", null);
    if (!analysis) return [];
    return (analysis.priority_gaps || []).map((g) => g.skill);
  }

  function calculateLearningRelevance(resource, currentProfile, skillGapNames, targetDomains) {
    const resourceSkills = resource.skills;
    const matchedGapSkills = resourceSkills.filter((s) => skillGapNames.includes(SkillGap.canonicalSkillName(s)));
    const domainRelevant = targetDomains.includes(resource.domain);
    const matchedExistingSkills = resourceSkills.filter((s) => Object.prototype.hasOwnProperty.call(currentProfile, SkillGap.canonicalSkillName(s)));

    let category, reason;
    if (matchedGapSkills.length) {
      category = "Highly Recommended";
      reason = matchedGapSkills.length === 1
        ? `Recommended because ${matchedGapSkills[0]} is one of your current skill gaps.`
        : `Recommended because it addresses your skill gaps in ${matchedGapSkills.join(", ")}.`;
    } else if (domainRelevant) {
      category = "Recommended";
      reason = `Recommended because it's in your target domain (${resource.domain}).`;
    } else if (matchedExistingSkills.length) {
      category = "Useful";
      reason = "Provides supporting skills related to what you already know.";
    } else {
      category = "Not Priority";
      reason = "Not currently a priority based on your profile.";
    }
    return { category, matched_gap_skills: matchedGapSkills, matched_gap_count: matchedGapSkills.length, domain_relevant: domainRelevant, reason };
  }

  function getRecommendations(resources, currentProfile, skillGapNames, targetDomains, limit) {
    const scored = [];
    for (const resource of resources) {
      const relevance = calculateLearningRelevance(resource, currentProfile, skillGapNames, targetDomains);
      if (relevance.category !== "Not Priority") scored.push([resource, relevance]);
    }
    scored.sort((a, b) => (CATEGORY_ORDER.indexOf(a[1].category) - CATEGORY_ORDER.indexOf(b[1].category)) || (b[1].matched_gap_count - a[1].matched_gap_count));
    return limit ? scored.slice(0, limit) : scored;
  }

  function countRecommendedResources(resources, currentProfile, skillGapNames, targetDomains) {
    return resources.filter((r) => ["Highly Recommended", "Recommended"].includes(calculateLearningRelevance(r, currentProfile, skillGapNames, targetDomains).category)).length;
  }

  function getSkillGapResources(skillName, resources, limit) {
    const canonicalTarget = SkillGap.canonicalSkillName(skillName);
    const matches = resources.filter((r) => r.skills.some((s) => SkillGap.canonicalSkillName(s) === canonicalTarget));
    return limit ? matches.slice(0, limit) : matches;
  }

  // ---- Save / progress (session-only) ----
  function isSavedResource(id) { return Storage.get("saved_learning_resources", []).includes(id); }
  function saveResource(id) {
    const list = Storage.get("saved_learning_resources", []);
    if (!list.includes(id)) { list.push(id); Storage.set("saved_learning_resources", list); }
  }
  function removeSavedResource(id) {
    Storage.set("saved_learning_resources", Storage.get("saved_learning_resources", []).filter((x) => x !== id));
  }
  function findProgressEntry(id) {
    return Storage.get("learning_progress", []).find((e) => e.resource_id === id) || null;
  }
  function getLearningStatus(id) {
    const entry = findProgressEntry(id);
    if (entry) return entry.status;
    if (isSavedResource(id)) return "Saved";
    return null;
  }
  function today() { return new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }); }
  function startResource(id) {
    if (findProgressEntry(id)) return;
    const progress = Storage.get("learning_progress", []);
    progress.push({ resource_id: id, status: "Started", started_date: today(), completed_date: null });
    Storage.set("learning_progress", progress);
  }
  function completeResource(id) {
    const progress = Storage.get("learning_progress", []);
    const entry = progress.find((e) => e.resource_id === id);
    if (!entry) progress.push({ resource_id: id, status: "Completed", started_date: today(), completed_date: today() });
    else { entry.status = "Completed"; entry.completed_date = today(); }
    Storage.set("learning_progress", progress);
  }
  function getMyLearningOverview() {
    const resources = loadLearningResources();
    const ids = new Set(Storage.get("saved_learning_resources", []));
    for (const e of Storage.get("learning_progress", [])) ids.add(e.resource_id);
    const overview = [];
    for (const id of ids) {
      const resource = getResourceById(resources, id);
      if (!resource) continue;
      const entry = findProgressEntry(id);
      overview.push({
        resource_id: id, title: resource.title,
        status: entry ? entry.status : "Saved",
        started_date: entry ? entry.started_date : null,
        completed_date: entry ? entry.completed_date : null,
      });
    }
    return overview;
  }

  function currentProfile() {
    return SkillGap.getCurrentSkillProfile(Storage.get("technical_skills", {}), Storage.get("soft_skills", {}), Storage.get("assessment_result", null));
  }

  // ---- Rendering ----
  function renderBrowse(container) {
    const resources = loadLearningResources();
    container.innerHTML = `
      ${UI.sectionHeader("Learning & Skill Development", "Browse courses, certifications, tutorials, workshops, training programs, and projects.")}
      <div class="search-row"><input type="text" id="lr-search" placeholder="Search by title, provider, skill, or domain"></div>
      <div class="filters-row">
        <select id="lr-type"><option value="All">All Types</option>${UI.selectOptions(DATA.RESOURCE_TYPES, "All", false)}</select>
        <select id="lr-domain"><option value="All">All Domains</option>${UI.selectOptions(DATA.LR_DOMAINS, "All", false)}</select>
        <select id="lr-level"><option value="All">All Levels</option>${UI.selectOptions(DATA.LEVELS, "All", false)}</select>
        <select id="lr-mode"><option value="All">All Modes</option>${UI.selectOptions(DATA.MODES, "All", false)}</select>
        <select id="lr-cost"><option value="All">All Costs</option>${UI.selectOptions(DATA.COSTS, "All", false)}</select>
      </div>
      <hr class="divider">
      <div id="lr-count" class="muted" style="margin-bottom:8px;"></div>
      <div class="grid grid-auto" id="lr-results"></div>`;

    const rerender = () => {
      const q = document.getElementById("lr-search").value;
      const filters = {
        type: document.getElementById("lr-type").value, domain: document.getElementById("lr-domain").value,
        level: document.getElementById("lr-level").value, mode: document.getElementById("lr-mode").value, cost: document.getElementById("lr-cost").value,
      };
      let results = searchResources(resources, q);
      results = filterResources(results, filters);
      document.getElementById("lr-count").textContent = `${results.length} resource${results.length === 1 ? "" : "s"} found`;
      const grid = document.getElementById("lr-results");
      grid.innerHTML = results.length ? results.map((r) => UI.learningCard(r)).join("") : UI.emptyState("No resources match your search and filters.");
      grid.querySelectorAll(".view-res-btn").forEach((btn) => btn.onclick = () => { Storage.set("selected_learning_resource", Number(btn.dataset.id)); renderSection(container); });
    };
    ["lr-search", "lr-type", "lr-domain", "lr-level", "lr-mode", "lr-cost"].forEach((id) => {
      document.getElementById(id).addEventListener("input", rerender);
      document.getElementById(id).addEventListener("change", rerender);
    });
    rerender();
  }

  function renderDetail(container, resource) {
    const profile = currentProfile();
    const status = getLearningStatus(resource.id);
    container.innerHTML = `
      <button class="back-link" id="lr-back">← Back to Learning</button>
      <h2>${UI.escapeHtml(resource.title)}</h2>
      <p><strong>${UI.escapeHtml(resource.provider)}</strong> • ${UI.escapeHtml(resource.type)} • ${UI.escapeHtml(resource.level)}</p>
      <div class="grid grid-3">
        <div><strong>Domain:</strong> ${UI.escapeHtml(resource.domain)}</div>
        <div><strong>Duration:</strong> ${UI.escapeHtml(resource.duration)}</div>
        <div><strong>Mode:</strong> ${UI.escapeHtml(resource.mode)} · <strong>Cost:</strong> ${UI.escapeHtml(resource.cost)}</div>
      </div>
      <hr class="divider">
      ${UI.sectionHeader("Description")}<p>${UI.escapeHtml(resource.description)}</p>
      ${UI.sectionHeader("Skills Covered")}<div>${UI.skillTags(resource.skills)}</div>
      <hr class="divider">
      ${UI.sectionHeader("Your Status")}
      <p>${status ? UI.badge(status, status === "Completed" ? "green" : status === "Started" ? "primary" : "amber") : `<span class="muted">Not started yet.</span>`}</p>
      <div class="btn-row">
        <button class="btn" id="lr-save-btn">${isSavedResource(resource.id) ? "Remove from Saved" : "Save Resource"}</button>
        <button class="btn btn-primary" id="lr-start-btn" ${status === "Started" || status === "Completed" ? "disabled" : ""}>Start Learning</button>
        <button class="btn btn-success" id="lr-complete-btn" ${status === "Completed" ? "disabled" : ""}>Mark Completed</button>
      </div>`;

    document.getElementById("lr-back").onclick = () => { Storage.set("selected_learning_resource", null); renderSection(container); };
    document.getElementById("lr-save-btn").onclick = () => { isSavedResource(resource.id) ? removeSavedResource(resource.id) : saveResource(resource.id); renderDetail(container, resource); };
    document.getElementById("lr-start-btn").onclick = () => { startResource(resource.id); UI.toast("Marked as Started", "success"); renderDetail(container, resource); };
    document.getElementById("lr-complete-btn").onclick = () => { completeResource(resource.id); UI.toast("Marked as Completed", "success"); renderDetail(container, resource); };
  }

  function renderSection(container) {
    const resources = loadLearningResources();
    const selectedId = Storage.get("selected_learning_resource", null);
    if (selectedId !== null) {
      const resource = getResourceById(resources, selectedId);
      if (!resource) { Storage.set("selected_learning_resource", null); renderBrowse(container); return; }
      renderDetail(container, resource);
      return;
    }
    renderBrowse(container);
  }

  function renderRecommendations(container) {
    const assessmentResult = Storage.get("assessment_result", null);
    if (!assessmentResult) {
      container.innerHTML = UI.sectionHeader("Recommended For You", "A simple, transparent recommendation list — not an AI score.") +
        `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">Complete your Skill Assessment (and Skill Gap Analysis) to get recommendations tailored to your skill gaps.</div>`;
      return;
    }
    const resources = loadLearningResources();
    const profile = currentProfile();
    const skillGapNames = getCurrentSkillGapNames();
    const targetRole = getEffectiveTargetRole();
    const targetDomains = DATA.ROLE_DOMAIN_RECOMMENDATIONS[targetRole] || [];

    let html = UI.sectionHeader("Recommended For You", "A simple, transparent recommendation list — not an AI score.");
    html += targetRole ? `<p><strong>Your Target Role:</strong> ${UI.escapeHtml(targetRole)}</p>` : `<p class="muted">Set a Target Job Role in My Profile to also get domain-based recommendations.</p>`;
    html += skillGapNames.length ? `<p><strong>Your Top Skill Gaps:</strong> ${skillGapNames.slice(0, 5).map(UI.escapeHtml).join(", ")}</p>` : `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">No skill-gap information is available yet. Run a Skill Gap Analysis to sharpen these recommendations.</div>`;
    html += `<hr class="divider">`;

    const recommendations = getRecommendations(resources, profile, skillGapNames, targetDomains, RECOMMENDATION_LIMIT);
    if (!recommendations.length) {
      html += `<p class="muted">No strongly relevant resources found yet — browse all resources in the tab above.</p>`;
    } else {
      html += UI.sectionHeader("Recommended Learning");
      html += recommendations.map(([resource, relevance], i) => `
        <div class="card">
          <div class="card-row"><div class="card-title">${i + 1}. ${UI.escapeHtml(resource.title)}</div>${UI.badge(relevance.category, relevance.category === "Highly Recommended" ? "green" : relevance.category === "Recommended" ? "primary" : "amber")}</div>
          <div class="card-sub">${UI.escapeHtml(resource.provider)} • ${UI.escapeHtml(resource.type)}</div>
          <p style="font-size:.85rem;">${UI.escapeHtml(relevance.reason)}</p>
          <button class="btn btn-primary btn-sm view-res-btn" data-id="${resource.id}">View Details</button>
        </div>`).join("");
    }
    container.innerHTML = html;
    container.querySelectorAll(".view-res-btn").forEach((btn) => btn.onclick = () => { Storage.set("selected_learning_resource", Number(btn.dataset.id)); Navigation.activateTab("learning"); });
  }

  function renderSaved(container) {
    const resources = loadLearningResources();
    const savedIds = Storage.get("saved_learning_resources", []);
    container.innerHTML = UI.sectionHeader("Saved Resources") + `<div id="saved-lr-list" class="grid grid-auto"></div>`;
    const el = document.getElementById("saved-lr-list");
    if (!savedIds.length) { el.innerHTML = UI.emptyState("You haven't saved any learning resources yet."); return; }
    el.innerHTML = resources.filter((r) => savedIds.includes(r.id)).map((r) => UI.learningCard(r)).join("");
    el.querySelectorAll(".view-res-btn").forEach((btn) => btn.onclick = () => { Storage.set("selected_learning_resource", Number(btn.dataset.id)); Navigation.activateTab("learning"); });
  }

  function renderMyLearning(container) {
    const overview = getMyLearningOverview();
    container.innerHTML = UI.sectionHeader("My Learning");
    if (!overview.length) { container.innerHTML += UI.emptyState("Nothing saved or started yet."); return; }
    container.innerHTML += overview.map((item) => `
      <div class="card">
        <div class="card-row"><div class="card-title">${UI.escapeHtml(item.title)}</div>${UI.badge(item.status, item.status === "Completed" ? "green" : item.status === "Started" ? "primary" : "amber")}</div>
        ${item.started_date ? `<div class="muted" style="font-size:.82rem;">Started: ${UI.escapeHtml(item.started_date)}${item.completed_date ? ` · Completed: ${UI.escapeHtml(item.completed_date)}` : ""}</div>` : ""}
      </div>`).join("");
  }

  function renderDashboardSummary(container) {
    const resources = loadLearningResources();
    const profile = currentProfile();
    const skillGapNames = getCurrentSkillGapNames();
    const targetRole = getEffectiveTargetRole();
    const targetDomains = DATA.ROLE_DOMAIN_RECOMMENDATIONS[targetRole] || [];
    const recommendedCount = countRecommendedResources(resources, profile, skillGapNames, targetDomains);
    const savedCount = Storage.get("saved_learning_resources", []).length;
    const progress = Storage.get("learning_progress", []);
    const completedCount = progress.filter((p) => p.status === "Completed").length;

    container.innerHTML = UI.sectionHeader("Learning & Skill Development") +
      UI.metricRow([["📚 Resources", resources.length], ["⭐ Saved", savedCount], ["🎯 Recommended", recommendedCount], ["✅ Completed", completedCount]]) +
      `<p class="muted">Open the <strong>Learning & Skill Development</strong> tab to browse and start learning.</p>`;
  }

  return {
    loadLearningResources, getResourceById, getEffectiveTargetRole, getCurrentSkillGapNames,
    calculateLearningRelevance, getRecommendations, getSkillGapResources, currentProfile,
    renderSection, renderRecommendations, renderSaved, renderMyLearning, renderDashboardSummary,
  };
})();
