/*
 * industry.js — Phase 8, ported from modules/industry/profile.py,
 * modules/industry/opportunities.py, modules/industry/candidates.py.
 */

const Industry = (() => {
  // ---------------- Profile ----------------
  function hasIndustryProfile() { return !!(Storage.get("industry_profile", {}).company_name); }
  function getCompanyName() { return Storage.get("industry_profile", {}).company_name || "Your Company"; }

  function renderProfile(container) {
    const profile = Storage.get("industry_profile", {});
    container.innerHTML = UI.sectionHeader("Industry Profile", "Basic company information used across the Industry portal.") + `
      <form id="industry-profile-form">
        <label>Company Name</label><input type="text" id="ip-name" value="${UI.escapeHtml(profile.company_name || "")}">
        <label>Industry Domain</label><select id="ip-domain">${UI.selectOptions(DATA.OPP_DOMAINS, profile.domain, false)}</select>
        <label>Company Description</label><textarea id="ip-desc">${UI.escapeHtml(profile.description || "")}</textarea>
        <label>Location</label><select id="ip-location">${UI.selectOptions(DATA.LOCATIONS, profile.location, false)}</select>
        <label>Website</label><input type="text" id="ip-website" value="${UI.escapeHtml(profile.website || "")}">
        <label>Contact Email</label><input type="text" id="ip-email" value="${UI.escapeHtml(profile.contact_email || "")}">
        <label>Company Size</label><select id="ip-size">${UI.selectOptions(DATA.COMPANY_SIZES, profile.company_size, false)}</select>
        <button type="submit" class="btn btn-primary">Save Profile</button>
      </form>`;
    document.getElementById("industry-profile-form").onsubmit = (e) => {
      e.preventDefault();
      const name = document.getElementById("ip-name").value.trim();
      if (!name) { UI.toast("Company Name cannot be empty.", "error"); return; }
      Storage.set("industry_profile", {
        company_name: name, domain: document.getElementById("ip-domain").value,
        description: document.getElementById("ip-desc").value.trim(), location: document.getElementById("ip-location").value,
        website: document.getElementById("ip-website").value.trim(), contact_email: document.getElementById("ip-email").value.trim(),
        company_size: document.getElementById("ip-size").value,
      });
      UI.toast("Industry profile saved.", "success");
      renderProfile(container);
    };
  }

  // ---------------- Opportunity CRUD ----------------
  function parseSkillList(text) { return text.split(",").map((s) => s.trim()).filter(Boolean); }
  function validateOpportunityFields(title, domain, description, requiredSkillsText) {
    const errors = [];
    if (!title.trim()) errors.push("Title cannot be empty.");
    if (!domain) errors.push("Domain must be selected.");
    if (!description.trim()) errors.push("Description should not be empty.");
    if (!parseSkillList(requiredSkillsText).length) errors.push("Required skills should contain at least one skill.");
    return errors;
  }
  function getNextOpportunityId() {
    const all = Opportunities.loadOpportunities();
    return Math.max(0, ...all.map((o) => o.id)) + 1;
  }
  function createOpportunity(fields) {
    const user = Auth.getCurrentUser();
    const newOpp = {
      id: getNextOpportunityId(), company: getCompanyName(), created_by: user ? user.email : null,
      title: fields.title.trim(), type: fields.type, domain: fields.domain, location: fields.location, mode: fields.mode,
      duration: fields.duration.trim() || "Not specified", stipend: fields.stipend.trim() || "Not specified",
      experience: fields.experience, required_skills: parseSkillList(fields.requiredSkillsText),
      preferred_skills: parseSkillList(fields.preferredSkillsText), description: fields.description.trim(),
      status: "Active", created_date: new Date().toLocaleDateString("en-GB", { day: "2-digit", month: "short", year: "numeric" }),
    };
    const list = Storage.get("industry_opportunities", []);
    list.push(newOpp);
    Storage.set("industry_opportunities", list);
    return newOpp.id;
  }
  function findOpportunityMutable(id) {
    const seedIdx = DATA.OPPORTUNITIES.findIndex((o) => o.id === id);
    if (seedIdx !== -1) return { list: DATA.OPPORTUNITIES, idx: seedIdx, persist: false };
    const posted = Storage.get("industry_opportunities", []);
    const idx = posted.findIndex((o) => o.id === id);
    if (idx !== -1) return { list: posted, idx, persist: true };
    return null;
  }
  function updateOpportunity(id, updates) {
    const found = findOpportunityMutable(id);
    if (!found) return;
    Object.assign(found.list[found.idx], updates);
    if (found.persist) Storage.set("industry_opportunities", found.list);
  }
  function closeOpportunity(id) { updateOpportunity(id, { status: "Closed" }); }
  function reopenOpportunity(id) { updateOpportunity(id, { status: "Active" }); }

  function renderPostForm(container) {
    if (!hasIndustryProfile()) {
      container.innerHTML = UI.sectionHeader("Post New Opportunity") + `<div class="auth-error" style="background:var(--primary-light);color:var(--primary-dark);">Complete your Industry Profile (Company Name) before posting an opportunity.</div>`;
      return;
    }
    container.innerHTML = UI.sectionHeader("Post New Opportunity") + `
      <form id="post-opp-form">
        <label>Opportunity Title</label><input type="text" id="po-title">
        <div class="grid grid-2">
          <div><label>Opportunity Type</label><select id="po-type">${UI.selectOptions(DATA.OPPORTUNITY_TYPES, null, false)}</select></div>
          <div><label>Domain</label><select id="po-domain">${UI.selectOptions(DATA.OPP_DOMAINS, null, false)}</select></div>
          <div><label>Location</label><select id="po-location">${UI.selectOptions(DATA.LOCATIONS, null, false)}</select></div>
          <div><label>Work Mode</label><select id="po-mode">${UI.selectOptions(DATA.WORK_MODES, null, false)}</select></div>
        </div>
        <label>Duration</label><input type="text" id="po-duration" placeholder="e.g. 6 Months">
        <label>Stipend/Salary</label><input type="text" id="po-stipend" placeholder="e.g. ₹15,000/month">
        <label>Experience Level</label><select id="po-experience">${UI.selectOptions(DATA.EXPERIENCE_LEVELS, null, false)}</select>
        <label>Description</label><textarea id="po-description"></textarea>
        <label>Required Skills (comma-separated)</label><input type="text" id="po-required" placeholder="Python, SQL, Statistics">
        <label>Preferred Skills (comma-separated)</label><input type="text" id="po-preferred" placeholder="Git, Power BI">
        <button type="submit" class="btn btn-primary">Post Opportunity</button>
      </form>`;
    document.getElementById("post-opp-form").onsubmit = (e) => {
      e.preventDefault();
      const title = document.getElementById("po-title").value, domain = document.getElementById("po-domain").value;
      const description = document.getElementById("po-description").value, required = document.getElementById("po-required").value;
      const errors = validateOpportunityFields(title, domain, description, required);
      if (errors.length) { errors.forEach((err) => UI.toast(err, "error")); return; }
      const id = createOpportunity({
        title, type: document.getElementById("po-type").value, domain,
        location: document.getElementById("po-location").value, mode: document.getElementById("po-mode").value,
        duration: document.getElementById("po-duration").value, stipend: document.getElementById("po-stipend").value,
        experience: document.getElementById("po-experience").value, description,
        requiredSkillsText: required, preferredSkillsText: document.getElementById("po-preferred").value,
      });
      UI.toast(`Opportunity posted (ID ${id}). See it in My Opportunities.`, "success");
      e.target.reset();
    };
  }

  function renderMyOpportunities(container) {
    const opportunities = Opportunities.loadOpportunities();
    if (!opportunities.length) { container.innerHTML = UI.sectionHeader("My Opportunities") + UI.emptyState("No opportunities yet. Post one in Post New Opportunity."); return; }

    const selectedId = Storage.get("selected_industry_opportunity", null);
    if (selectedId !== null) {
      const opp = Opportunities.getOpportunityById(opportunities, selectedId);
      if (!opp) { Storage.set("selected_industry_opportunity", null); renderMyOpportunities(container); return; }
      renderManageView(container, opp);
      return;
    }

    container.innerHTML = UI.sectionHeader("My Opportunities") + opportunities.map((o) => `
      <div class="card">
        <div class="card-title">${UI.escapeHtml(o.title)}</div>
        <div class="card-sub">${UI.escapeHtml(o.type)} • ${UI.escapeHtml(o.domain)} • ${UI.escapeHtml(o.location)}</div>
        <div>Applications: ${Applications.countApplicationsForOpportunity(o.id)}</div>
        <div>Status: ${UI.badge(o.status || "Active", (o.status || "Active") === "Active" ? "green" : "red")}</div>
        ${o.created_date ? `<div class="muted" style="font-size:.8rem;">Created: ${UI.escapeHtml(o.created_date)}</div>` : ""}
        <button class="btn btn-primary btn-sm manage-opp-btn" data-id="${o.id}" style="margin-top:8px;">Manage</button>
      </div>`).join("");

    container.querySelectorAll(".manage-opp-btn").forEach((btn) => btn.onclick = () => { Storage.set("selected_industry_opportunity", Number(btn.dataset.id)); renderMyOpportunities(container); });
  }

  function renderManageView(container, opportunity) {
    container.innerHTML = `
      <button class="back-link" id="my-opp-back">← Back to My Opportunities</button>
      <h2>${UI.escapeHtml(opportunity.title)}</h2>
      <p><strong>Status:</strong> ${UI.escapeHtml(opportunity.status || "Active")}</p>
      <p>Applications received: ${Applications.countApplicationsForOpportunity(opportunity.id)}</p>
      <div class="btn-row" style="margin-bottom:16px;">
        ${(opportunity.status || "Active") === "Active"
          ? `<button class="btn btn-danger" id="close-opp-btn">Close Opportunity</button>`
          : `<button class="btn btn-success" id="reopen-opp-btn">Reopen Opportunity</button>`}
      </div>
      <hr class="divider">
      ${UI.sectionHeader("Edit Opportunity")}
      <form id="edit-opp-form">
        <label>Title</label><input type="text" id="eo-title" value="${UI.escapeHtml(opportunity.title)}">
        <label>Description</label><textarea id="eo-description">${UI.escapeHtml(opportunity.description)}</textarea>
        <div class="grid grid-2">
          <div><label>Location</label><select id="eo-location">${UI.selectOptions(DATA.LOCATIONS, opportunity.location, false)}</select></div>
          <div><label>Work Mode</label><select id="eo-mode">${UI.selectOptions(DATA.WORK_MODES, opportunity.mode, false)}</select></div>
        </div>
        <label>Duration</label><input type="text" id="eo-duration" value="${UI.escapeHtml(opportunity.duration)}">
        <label>Stipend/Salary</label><input type="text" id="eo-stipend" value="${UI.escapeHtml(opportunity.stipend)}">
        <label>Experience</label><select id="eo-experience">${UI.selectOptions(DATA.EXPERIENCE_LEVELS, opportunity.experience, false)}</select>
        <label>Required Skills (comma-separated)</label><input type="text" id="eo-required" value="${UI.escapeHtml(opportunity.required_skills.join(", "))}">
        <label>Preferred Skills (comma-separated)</label><input type="text" id="eo-preferred" value="${UI.escapeHtml(opportunity.preferred_skills.join(", "))}">
        <button type="submit" class="btn btn-primary">Save Changes</button>
      </form>`;

    document.getElementById("my-opp-back").onclick = () => { Storage.set("selected_industry_opportunity", null); renderMyOpportunities(container); };
    document.getElementById("close-opp-btn")?.addEventListener("click", () => { closeOpportunity(opportunity.id); renderManageView(container, opportunity); });
    document.getElementById("reopen-opp-btn")?.addEventListener("click", () => { reopenOpportunity(opportunity.id); renderManageView(container, opportunity); });
    document.getElementById("edit-opp-form").onsubmit = (e) => {
      e.preventDefault();
      const title = document.getElementById("eo-title").value, description = document.getElementById("eo-description").value, required = document.getElementById("eo-required").value;
      const errors = validateOpportunityFields(title, opportunity.domain, description, required);
      if (errors.length) { errors.forEach((err) => UI.toast(err, "error")); return; }
      updateOpportunity(opportunity.id, {
        title: title.trim(), description: description.trim(), location: document.getElementById("eo-location").value,
        mode: document.getElementById("eo-mode").value, duration: document.getElementById("eo-duration").value.trim(),
        stipend: document.getElementById("eo-stipend").value.trim(), experience: document.getElementById("eo-experience").value,
        required_skills: parseSkillList(required), preferred_skills: parseSkillList(document.getElementById("eo-preferred").value),
      });
      UI.toast("Opportunity updated.", "success");
      renderManageView(container, Opportunities.getOpportunityById(Opportunities.loadOpportunities(), opportunity.id));
    };
  }

  // ---------------- Candidate search & profile ----------------
  function renderCandidateSearch(container) {
    const selectedId = Storage.get("selected_candidate", null);
    if (selectedId !== null) { renderCandidateProfile(container, selectedId); return; }

    const candidates = Candidates.getAllCandidates();
    container.innerHTML = UI.sectionHeader("Candidate Search") + `
      <div class="search-row"><input type="text" id="cand-search" placeholder="Search by name, skill, or target role"></div>
      <div class="filters-row">
        <select id="cand-role-filter"><option value="All">All Roles</option>${UI.selectOptions(Candidates.KNOWN_ROLES, "All", false)}</select>
        <select id="cand-skill-filter"><option value="All">All Skills</option>${UI.selectOptions([...new Set(candidates.flatMap((c) => Object.keys(c.skill_profile)))].sort(), "All", false)}</select>
        <select id="cand-domain-filter"><option value="All">All Domains</option>${UI.selectOptions(DATA.OPP_DOMAINS, "All", false)}</select>
      </div>
      <div id="cand-count" class="muted" style="margin-bottom:8px;"></div>
      <div class="grid grid-auto" id="cand-results"></div>`;

    const rerender = () => {
      const q = (document.getElementById("cand-search").value || "").trim().toLowerCase();
      const roleFilter = document.getElementById("cand-role-filter").value;
      const skillFilter = document.getElementById("cand-skill-filter").value;
      const domainFilter = document.getElementById("cand-domain-filter").value;
      let results = candidates;
      if (q) results = results.filter((c) => [c.name, c.target_role || "", c.domain || "", ...Object.keys(c.skill_profile)].some((v) => v.toLowerCase().includes(q)));
      if (roleFilter !== "All") results = results.filter((c) => c.target_role === roleFilter);
      if (skillFilter !== "All") results = results.filter((c) => skillFilter in c.skill_profile);
      if (domainFilter !== "All") results = results.filter((c) => c.domain === domainFilter);

      document.getElementById("cand-count").textContent = `${results.length} candidate${results.length === 1 ? "" : "s"} found`;
      const grid = document.getElementById("cand-results");
      grid.innerHTML = results.length ? results.map((c) => UI.candidateCard(c)).join("") : UI.emptyState("No candidates match your search and filters.");
      grid.querySelectorAll(".view-cand-btn").forEach((btn) => btn.onclick = () => { const id = btn.dataset.id === "self" ? "self" : Number(btn.dataset.id); Storage.set("selected_candidate", id); renderCandidateSearch(container); });
    };
    ["cand-search", "cand-role-filter", "cand-skill-filter", "cand-domain-filter"].forEach((id) => {
      document.getElementById(id).addEventListener("input", rerender);
      document.getElementById(id).addEventListener("change", rerender);
    });
    rerender();
  }

  function certificationNames(certifications) {
    return (certifications || []).map((c) => (typeof c === "object" ? c.certification_name || "Untitled Certification" : c));
  }

  function renderCandidateProfile(container, candidateId) {
    const candidate = Candidates.getCandidateById(null, candidateId);
    if (!candidate) { container.innerHTML = UI.emptyState("This candidate's profile is no longer available."); return; }

    const gapResult = Candidates.computeCandidateSkillGap(candidate);
    container.innerHTML = `
      <button class="back-link" id="cand-back">← Back</button>
      <h2>${UI.escapeHtml(candidate.name)}</h2>
      <p><strong>Target Career:</strong> ${UI.escapeHtml(candidate.target_role || "Not set")}</p>
      <hr class="divider">
      ${UI.sectionHeader("Skills & Proficiency")}
      ${Object.keys(candidate.skill_profile).length ? Object.entries(candidate.skill_profile).map(([s, v]) => UI.skillBar(s, v)).join("") : `<span class="muted">No skill data available for this candidate yet.</span>`}
      <hr class="divider">
      ${UI.sectionHeader("Certifications")}
      ${certificationNames(candidate.certifications).length ? `<ul class="list-clean">${certificationNames(candidate.certifications).map((n) => `<li>• ${UI.escapeHtml(n)}</li>`).join("")}</ul>` : `<span class="muted">No certifications listed.</span>`}
      <hr class="divider">
      ${UI.sectionHeader("Portfolio")}
      ${(candidate.projects && candidate.projects.length) ? `<ul class="list-clean">${candidate.projects.map((p) => `<li>• ${UI.escapeHtml(p.project_name || "Untitled Project")}</li>`).join("")}</ul>`
        : candidate.portfolio_project_count ? `<p>${candidate.portfolio_project_count} project(s) listed.</p>` : `<span class="muted">No portfolio projects listed.</span>`}
      <hr class="divider">
      ${UI.sectionHeader("Skill Gaps")}
      ${!gapResult ? `<span class="muted">No skill-gap data available for this candidate's target role.</span>` : `
        <p>Readiness for ${UI.escapeHtml(gapResult.target_role)}: ${gapResult.readiness_score}%</p>
        ${gapResult.priority_gaps.length ? gapResult.priority_gaps.map((g) => `<div>✗ ${UI.escapeHtml(g.skill)} (gap: ${g.gap} points)</div>`).join("") : `<div class="auth-success">No significant skill gaps for this role.</div>`}
      `}`;
    document.getElementById("cand-back").onclick = () => { Storage.set("selected_candidate", null); Navigation.activateTab("candidate-search"); };
  }

  // ---------------- Talent discovery ----------------
  function renderTalentDiscovery(container) {
    const opportunities = Opportunities.loadOpportunities();
    if (!opportunities.length) { container.innerHTML = UI.sectionHeader("Talent Discovery") + UI.emptyState("Post an opportunity first to discover matching candidates."); return; }

    container.innerHTML = UI.sectionHeader("Talent Discovery", "Candidates ranked against one of your opportunities, using the same matching engine students see.") +
      `<select id="td-opp-select">${opportunities.map((o) => `<option value="${o.id}">${UI.escapeHtml(o.title)}</option>`).join("")}</select>
      <div id="td-results"></div>`;

    const rerender = () => {
      const oppId = Number(document.getElementById("td-opp-select").value);
      const opportunity = opportunities.find((o) => o.id === oppId);
      const ranked = Candidates.rankCandidatesForOpportunity(opportunity, null, 5);
      const resultsEl = document.getElementById("td-results");
      if (!ranked.length) { resultsEl.innerHTML = UI.emptyState("No candidates available to rank yet."); return; }
      resultsEl.innerHTML = UI.sectionHeader(`Top Candidates for ${opportunity.title}`) + ranked.map((r, i) => `
        <div class="card">
          <div class="card-title">${i + 1}. ${UI.escapeHtml(r.candidate_name)} — ${r.match_score}%</div>
          ${r.reasons.map((reason) => `<div class="muted" style="font-size:.82rem;">✓ ${UI.escapeHtml(reason)}</div>`).join("")}
          <button class="btn btn-primary btn-sm view-cand-btn" data-id="${r.candidate_id}" style="margin-top:8px;">View Candidate</button>
        </div>`).join("");
      resultsEl.querySelectorAll(".view-cand-btn").forEach((btn) => btn.onclick = () => { const id = btn.dataset.id === "self" ? "self" : Number(btn.dataset.id); Storage.set("selected_candidate", id); Navigation.activateTab("candidate-search"); });
    };
    document.getElementById("td-opp-select").addEventListener("change", rerender);
    rerender();
  }

  // ---------------- Industry analytics (Phase 8 summary + Phase 13 live data) ----------------
  function renderIndustryAnalytics(container) {
    const opportunities = Opportunities.loadOpportunities();
    const applications = Applications.getAllCandidateApplications();
    const active = opportunities.filter((o) => (o.status || "Active") === "Active").length;
    const shortlisted = applications.filter((a) => a.status === "Shortlisted").length;

    const demand = AnalyticsMetrics.calculateSkillDemand(opportunities);
    const topSkills = Object.entries(demand).slice(0, 8);

    container.innerHTML = `<div id="ia-live"></div>` +
      UI.sectionHeader("Industry Analytics", "Your own posted opportunities and applications.") +
      UI.metricRow([["Opportunities Posted", opportunities.length], ["Active", active], ["Applications", applications.length], ["Shortlisted", shortlisted]]) +
      UI.sectionHeader("Top Skills in Demand (Your Opportunities' Market)") +
      topSkills.map(([skill, v]) => `<div>${UI.skillBar(skill, Math.min(100, v.total * 10))}<div class="muted" style="font-size:.78rem;margin-top:-6px;">${v.total} opportunities (required: ${v.required}, preferred: ${v.preferred})</div></div>`).join("");

    LiveIndustry.renderIndustryLiveSection(document.getElementById("ia-live"));
  }

  // ---------------- Dashboard ----------------
  function renderDashboard(container) {
    const opportunities = Opportunities.loadOpportunities();
    const applications = Applications.getAllCandidateApplications();
    const active = opportunities.filter((o) => (o.status || "Active") === "Active").length;
    const shortlisted = applications.filter((a) => a.status === "Shortlisted").length;

    container.innerHTML = `
      <div class="page-header"><h1>Welcome, ${UI.escapeHtml(getCompanyName())}</h1><p>Your recruiting activity at a glance.</p></div>
      ${UI.metricRow([["Opportunities Posted", opportunities.length], ["Active Opportunities", active], ["Applications Received", applications.length], ["Shortlisted", shortlisted]])}
      <div class="grid grid-2">
        <div class="card"><div class="card-title">Post a New Opportunity</div><p class="muted">Reach students actively browsing internships and jobs.</p><button class="btn btn-primary btn-sm" id="dash-post-btn">Post Opportunity</button></div>
        <div class="card"><div class="card-title">Discover Talent</div><p class="muted">Rank candidates against your open roles using the shared matching engine.</p><button class="btn btn-primary btn-sm" id="dash-discover-btn">Open Talent Discovery</button></div>
      </div>`;
    document.getElementById("dash-post-btn").onclick = () => Navigation.activateTab("post-opportunity");
    document.getElementById("dash-discover-btn").onclick = () => Navigation.activateTab("talent-discovery");
  }

  return {
    hasIndustryProfile, getCompanyName, renderProfile, renderPostForm, renderMyOpportunities,
    renderCandidateSearch, renderTalentDiscovery, renderIndustryAnalytics, renderDashboard,
  };
})();
