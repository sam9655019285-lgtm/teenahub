/*
 * auth.js — Phase 11 authentication, converted from
 * modules/auth/auth_manager.py + modules/auth/session.py.
 *
 * Prototype authentication uses browser-side storage and is not
 * suitable for production. Passwords are hashed with the Web Crypto
 * API (SHA-256) before being stored — never in plain text — but this
 * is still a client-side-only demo with no real backend, exactly
 * like the Streamlit prototype it replaces.
 *
 * data/users.json (SHA-256 hex digests, same algorithm as the old
 * Python hashlib.sha256) is used to seed localStorage the first time
 * the app runs, so the four demo accounts keep working exactly as
 * before.
 */

const VALID_ROLES = ["Student", "Industry", "Academician", "Institution"];

const Auth = (() => {
  let _currentUser = null; // cached in-memory mirror of sessionStorage

  // --------------------------------------------------------------
  // Password hashing (Phase 11 spec point 6/7)
  // --------------------------------------------------------------
  async function hashPassword(password) {
    const enc = new TextEncoder().encode(password);
    const digest = await crypto.subtle.digest("SHA-256", enc);
    return Array.from(new Uint8Array(digest))
      .map((b) => b.toString(16).padStart(2, "0"))
      .join("");
  }

  // --------------------------------------------------------------
  // Seed data/users.json into localStorage on first run only.
  // --------------------------------------------------------------
  function seedUsersIfNeeded() {
    const existing = Storage.getUsers();
    if (existing && existing.length) return;
    Storage.saveUsers(JSON.parse(JSON.stringify(DATA.USERS_SEED || SEED_USERS)));
  }

  function getUserByEmail(email) {
    const normalized = (email || "").trim().toLowerCase();
    return Storage.getUsers().find((u) => (u.email || "").trim().toLowerCase() === normalized) || null;
  }

  // --------------------------------------------------------------
  // Registration (Phase 11 spec point 7 / register.html)
  // --------------------------------------------------------------
  async function registerUser(name, email, password, confirmPassword, role) {
    name = (name || "").trim();
    email = (email || "").trim().toLowerCase();

    if (!name || !email || !password || !confirmPassword) {
      return { success: false, message: "Please fill in all fields." };
    }
    if (!VALID_ROLES.includes(role)) {
      return { success: false, message: "Please select a valid role." };
    }
    if (password !== confirmPassword) {
      return { success: false, message: "Passwords do not match." };
    }
    if (password.length < 6) {
      return { success: false, message: "Password must be at least 6 characters long." };
    }

    const users = Storage.getUsers();
    if (getUserByEmail(email)) {
      return { success: false, message: "An account with this email already exists." };
    }

    const newId = users.reduce((max, u) => Math.max(max, u.id || 0), 0) + 1;
    users.push({
      id: newId,
      name,
      email,
      password: await hashPassword(password),
      role,
    });
    Storage.saveUsers(users);
    return { success: true, message: "Account created successfully." };
  }

  // --------------------------------------------------------------
  // Login (Phase 11 spec point 8 / login.html)
  // --------------------------------------------------------------
  async function authenticateUser(email, password) {
    if (!email || !password) {
      return { user: null, error: "Please enter both email and password." };
    }
    const user = getUserByEmail(email);
    if (!user) {
      return { user: null, error: "No account found with this email." };
    }
    const hashed = await hashPassword(password);
    if (hashed !== user.password) {
      return { user: null, error: "Incorrect password." };
    }
    const { password: _pw, ...publicUser } = user;
    return { user: publicUser, error: null };
  }

  // --------------------------------------------------------------
  // Session (sessionStorage — cleared when the tab closes, same
  // lifetime feel as Streamlit's st.session_state)
  // --------------------------------------------------------------
  function loginUser(user) {
    sessionStorage.setItem("aisb:currentUser", JSON.stringify(user));
    _currentUser = user;

    // Phase 11 spec point 13: link the account to the existing Phase
    // 2 student_profile / Phase 8 industry_profile — only fills
    // fields that are still empty.
    if (user.role === "Student") {
      Storage.initStudentData();
      const profile = Storage.get("student_profile", {});
      if (!profile.full_name) profile.full_name = user.name || "";
      if (!profile.email) profile.email = user.email || "";
      Storage.set("student_profile", profile);
    } else if (user.role === "Industry") {
      Storage.initIndustryData();
      const profile = Storage.get("industry_profile", {});
      if (!profile.contact_email) profile.contact_email = user.email || "";
      Storage.set("industry_profile", profile);
    }
  }

  function logoutUser() {
    sessionStorage.removeItem("aisb:currentUser");
    _currentUser = null;
  }

  function getCurrentUser() {
    if (_currentUser) return _currentUser;
    try {
      const raw = sessionStorage.getItem("aisb:currentUser");
      _currentUser = raw ? JSON.parse(raw) : null;
    } catch (e) {
      _currentUser = null;
    }
    return _currentUser;
  }

  function isLoggedIn() {
    return !!getCurrentUser();
  }

  // --------------------------------------------------------------
  // Page protection (Phase 11 spec point 8 / navigation.js uses these)
  // --------------------------------------------------------------
  function requireLogin() {
    if (!isLoggedIn()) {
      window.location.href = "login.html";
      return false;
    }
    return true;
  }

  function requireRole(allowedRoles) {
    if (!requireLogin()) return false;
    const user = getCurrentUser();
    if (!allowedRoles.includes(user.role)) {
      alert("Access denied.");
      window.location.href = roleDashboardUrl(user.role);
      return false;
    }
    return true;
  }

  function roleDashboardUrl(role) {
    switch (role) {
      case "Student": return "student.html";
      case "Industry": return "industry.html";
      case "Academician": return "academician.html";
      case "Institution": return "institution.html";
      default: return "login.html";
    }
  }

  return {
    hashPassword, seedUsersIfNeeded, getUserByEmail,
    registerUser, authenticateUser,
    loginUser, logoutUser, getCurrentUser, isLoggedIn,
    requireLogin, requireRole, roleDashboardUrl,
  };
})();
