/*
 * js/api/apiClient.js — Phase 13 spec point 27.
 *
 * The ONLY place in the frontend that knows the backend's URL. Talks
 * exclusively to our own backend (never LinkedIn or any other
 * external API directly), and never holds an API key, secret, or
 * access token — those live only in backend/.env.
 */

const ApiClient = (() => {
  // Change this if your backend runs somewhere other than localhost:3000.
  const BASE_URL = (window.API_BASE_URL) || "http://localhost:3000";
  const REQUEST_TIMEOUT_MS = 8000;

  async function getJson(path, { timeoutMs = REQUEST_TIMEOUT_MS } = {}) {
    const controller = new AbortController();
    const timer = setTimeout(() => controller.abort(), timeoutMs);
    try {
      const res = await fetch(`${BASE_URL}${path}`, { signal: controller.signal });
      clearTimeout(timer);
      if (!res.ok) return { ok: false, error: `Backend responded with status ${res.status}.` };
      const data = await res.json();
      return { ok: true, data };
    } catch (err) {
      clearTimeout(timer);
      const reason = err.name === "AbortError" ? "The request timed out." : "Could not reach the backend API.";
      return { ok: false, error: reason };
    }
  }

  function getJobs(forceRefresh = false) {
    return getJson(`/api/jobs${forceRefresh ? "?refresh=true" : ""}`);
  }
  function getSkillDemand() {
    return getJson("/api/skills/demand");
  }
  function getIndustryTrends() {
    return getJson("/api/industry/trends");
  }
  function getApiStatus() {
    return getJson("/api/industry/status");
  }

  return { BASE_URL, getJobs, getSkillDemand, getIndustryTrends, getApiStatus };
})();
